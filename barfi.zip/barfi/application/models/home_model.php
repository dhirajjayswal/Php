<?php

  if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
  }  

  class home_model extends CI_Model {

    //fetching product category from db
  //   public function get_details(){

  //     $data = $this->db->get('barfi_product_cat');
  //    if($data->num_rows() > 0 ){
  //      return$data->result_array();
       
  //   }
  // }

    public function get_6_products() {
      /* Fetching Latest products from the database */
      $data = $this->db->select('*')
              // ->from('tbl_product')
              ->order_by("id", "desc")
              ->limit(6)
              ->get('tbl_product')
              ->result_array();
      // echo $this->db->last_query();exit();////////
      return $data;
    }
    public function get_products($limit=0, $start=0, $where=array()) {
      /* Fetching Latest products from the database */
       // echo "<pre>";
      $where_temp = array();
      foreach ($where as $key => $value) {
        $where_temp[$key] = implode('","',(array)$value);
      }
      // print_r($where_temp);exit();
      // print_r($where_temp);
      //echo($where_temp["main_categories"]);

      // exit();
      $this->db->select('*');
      if (isset($where_temp["main_categories"])) {
        $this->db->where("main_categories",'"'.$where_temp["main_categories"].'"',FALSE);
      }
      if (isset($where_temp["category"])) {
        $this->db->where_in("category",'"'.$where_temp["category"].'"',FALSE);
      }
      if (isset($where_temp["subcategory"])) {
        $this->db->where_in("sub_category",'"'.$where_temp["subcategory"].'"',FALSE);
      }
      if (isset($where_temp["brand_name"])) {
        $this->db->where_in("brand_name",'"'.$where_temp["brand_name"].'"',FALSE);
      }
      if (isset($where_temp["colors"])) {
        $ctemp = explode('","', $where_temp["colors"]);
        foreach ($ctemp as $key => $value) {
          $this->db->like("colors",$value,TRUE);
        }
      }

      $this->db->limit($limit,$start);
      $data =  $this->db->get('tbl_product')->result_array();
      //echo $this->db->last_query();
      return $data;
    }
    public function get_product_cat() {
      /* Fetching Latest products cat from the database */
      $data = $this->db->select('*')
              ->get('barfi_product_cat')
              ->result_array();
      // echo $this->db->last_query();exit();
      return $data;
    }
    public function get_product_subcat() {
      /* Fetching Latest products cat from the database */
      $data = $this->db->select('*')
              ->get('barfi_product_subcat')
              ->result_array();
      // echo $this->db->last_query();exit();
      return $data;
    }
    public function get_product_colors() {
      /* Fetching Latest products colors from the database */
      $data = $this->db->select('*')
              ->get('barfi_product_color')
              ->result_array();
      // echo $this->db->last_query();exit();
      return $data;
    }
    public function get_product_brand() {
      /* Fetching Latest products colors from the database */
      $data = $this->db->select('*')
              ->get('barfi_product_brand')
              ->result_array();
      // echo $this->db->last_query();exit();
      return $data;
    }
    public function get_product_images($pid) {
      /* Fetching Latest products images from the database */
      $data = $this->db->select('*')
              ->where("product_id",$pid)
              ->get('barfi_product_imgs')
              ->result_array();
      // echo $this->db->last_query();exit();
      return $data;
    }

    public function get_gallery_images($g_id=""){
 
      $g = array('id'=>$g_id);
       $data = $this->db->select('*')
              ->where('product_id',$g_id)
              ->get('barfi_product_imgs')
              ->result_array();
              return $data;

    }

    public function get_product_info($pid) {
      /* Fetching Latest products images from the database */
      $a = array('id'=>$pid);
      $data = $this->db->select('*')
              ->where('id',$pid)
              ->get('tbl_product')
              ->result_array();
      // echo $this->db->last_query();exit();
      return $data;

    }

    

    public function get_all_products() {
      /* Fetching Latest products images from the database */
      // $a = array('id'=>$pid);
      $data = $this->db->select('*')
              // ->where('id',$pid)
              ->get('tbl_product')
              ->result_array();
      // echo $this->db->last_query();exit();
      return $data;

    }

    public function contact(){
      // pfrint_r($_POST);
      if (isset($_POST) && !empty($_POST)) {
        $data = array(

              'name' => $_POST['name'],
              'email' => $_POST['email'],
              'phone' => $_POST['mobile'],
              'subject' => $_POST['subject'],
              'message' => $_POST['message']
        );
        if ($this->db->insert('barfi_contact', $data)) {
          return "Form Submitted Successfully!!!";
        } else {
          return "could not insert: ".$this->db->mysql_error(); 
        }       

      } else {
        return;
      }
      
      
    }

   public function retailer_login() {

        // $pass = $this->input->post('password');
        $data = $this->db->select("*")
                ->from('tbl_admin_master')
                ->where('user_name',$_POST['username'])
                ->where('password', $_POST['password'])
                ->get()
                ->num_rows();

        $uid = 0;

          if (!empty($data)) {
            $user = $this->db->select('*')
                    ->from('tbl_admin_master')
                    ->where('user_name', $_POST['username'])
                    ->where('password', $_POST['password'])
                    ->get()
                    ->row();

            if (isset($user->user_id) && !empty($user->user_id)) {
              $user_details = $this->db->select('*')
                    ->from('barfi_retailers')
                    ->where('id', $user->user_id)
                    ->get()
                    ->row();
                    // print_r($user_details);exit();
              if (!empty($user_details)) {
                $uid = $user_details->id;
              }
            }
                // echo "$uid";exit();
            

            if ($user->otp == 1 && $uid!=0) {
              redirect("home/retailer_reset_pwd/$uid");
            } else {
              $newdata = array(
                'user_id' => $uid,
                'user_role' => $user->role,
                'user_status' => $user->status,
                'user_name' => $user->user_name,
                'logged_in' => TRUE,
              );
              $this->session->set_userdata($newdata);
            }
            

            
        }
        return $data;
    }
          
      public function retailer_reset_pwd($uid="",$pwd="") {
        // echo "$uid and $pwd";exit();
        $data = array(
            'password' => $pwd,
            'status'=>"active",
            'otp'=>0
        );
        $this->db->where('user_id', $uid);
        $this->db->update('tbl_admin_master', $data) or die("Error :".$this->db->mysql_error());

        $user = $this->db->select('*')
                    ->from('tbl_admin_master')
                    ->where('user_id', $uid)
                    ->get()
                    ->row();
        $newdata = array(
                'user_id' => $user->user_id,
                'user_role' => $user->role,
                'user_status' => $user->status,
                'user_name' => $user->user_name,
                'logged_in' => TRUE,
              );
        $this->session->set_userdata($newdata);
        redirect("Admin/dashboard");
      }


              
   

    public function get_products_count() {
      /* Fetching Latest products count from the database */      
      return $this->db->count_all("tbl_product");
    }

    public function add_order()
    {
      // echo "".$this->input->post("p_name1");
      $date = date("d-m-Y G-i-s");
      $data = array(
            'product_id' => $_POST['prod_id'],
            'product_name' => $_POST['prod_name'],
            'product_brand' => $_POST['prod_brand'],
            'product_code' => $_POST['prod_code'],
            'prod_desc' => $_POST['prod_desc'],
            //'product_req_quantity' => $_POST['prod_req_qty'],
            'comments' => $_POST['prod_cmnts'],
            'product_cat' => $_POST['prod_cat'],
            'product_subcat' => $_POST['prod_subcat'],
            'product_color' => $_POST['prod_color'],
            'product_avl_quantity' => $_POST['prod_avl_qty'],
            //'product_mrp' => $_POST['prod_mrp'],
            //'retailer_name' => $_POST['prod_rtlr'],
            'user_name' => $_POST['prod_user'],
            'email' => $_POST['user_email'],
            'contact_no' => $_POST['prod_cntct'],
            //'order_address' => $_POST['prod_addrs'],
            //'gst' => $_POST['prod_gst'],
            //'discount' => $_POST['prod_disc'],
            //'total' => $_POST['prod_total'],
            'timestamp' => $date
            
        );
        return $this->db->insert('barfi_enquire', $data) or die("could not insert: ".$this->db->mysql_error());
        // return $this->db->insert('barfi_orders', $data) or die("could not insert: ".$this->db->mysql_error());
    }
  }

