<?php

if (!defined('BASEPATH'))
  {
    exit('No direct script access allowed');
  }  

class admin_model extends CI_Model {

    public function check_user() {
// $pass = $this->input->post('password');
        $data = $this->db->select()
                ->from('tbl_admin_master')
                ->where('user_name', $_POST['username'])
                ->where('password', $_POST['password'])
                ->get()
                ->num_rows();
        if (!empty($data)) {
            $user = $this->db->select('id, user_name, role, status')
                    ->from('tbl_admin_master')
                    ->where('user_name', $_POST['username'])
                    ->where('password', $_POST['password'])
                    ->get()
                    ->row();

            $newdata = array(
                'user_id' => $user->id,
                'user_role' => $user->role,
                'user_status' => $user->status,
                'user_name' => $user->user_name,
//                'user_role' => $user->user_role,
                'logged_in' => TRUE,
            );
            $this->session->set_userdata($newdata);
        }
        return $data;
    }

    public function add_seller() {
        $data = array(
            'c_name' => $_POST['c_name'],
            's_name' => $_POST['s_name'],
            'email' => $_POST['email'],
            'number' => $_POST['number'],
            'address' => $_POST['add'],
            'pincode' => $_POST['pincode'],
            'location' => $_POST['location'],
        );
        $this->db->insert('tbl_seller', $data);
    }

    public function get_seller() {
        $data = $this->db->select('*')
                ->from('tbl_seller')
                ->get()
                ->result();
        return $data;
    }

    public function delete_seller($id) {
        $this->db->where('id', $id);
        $this->db->delete('tbl_seller');
    }

    public function get_seller_id($id) {
        $data = $this->db->select('*')
                ->from('tbl_seller')
                ->where('id', $id)
                ->get()
                ->row();
        return $data;
    }

    public function update_seller() {
        $id = $_POST['seller_id'];
        $data = array(
            'c_name' => $_POST['c_name'],
            's_name' => $_POST['s_name'],
            'email' => $_POST['email'],
            'number' => $_POST['number'],
            'address' => $_POST['add'],
            'pincode' => $_POST['pincode'],
            'location' => $_POST['location'],
        );
        $this->db->where('id', $id);
        $this->db->update('tbl_seller', $data);
    }

    public function get_seller_count() {
        $data = $this->db->select('*')
                ->from('tbl_seller')
                ->get()
                ->num_rows();
        return $data;
    }
    public function get_order_count() {
      $data = $this->db->select('*')
              ->from('barfi_orders')
              ->get()
              ->num_rows();
      return $data;
    }
    public function get_product_count() {
          $data = $this->db->select('*')
                  ->from('tbl_product')
                  ->get()
                  ->num_rows();
          return $data;
        }

    public function get_packages($user_name)
    {
        $data = $this->db->select('*')
                ->from('tbl_packages')
                ->where('added_by',$user_name)
                ->get()
                ->result_array();//Returned as array
        return $data;
    }

    public function get_colors()
    {
        $data = $this->db->select('*')
                ->from('barfi_product_color')
                ->get()
                ->result_array();//Returned as array
        return $data;
    }

}
