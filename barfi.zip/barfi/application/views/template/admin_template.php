<?php
$this->load->view('admin/header.php');
$this->load->view('admin/menu.php');
$this->load->view('admin/' . $content);
$this->load->view('admin/footer.php');
?>