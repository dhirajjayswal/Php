<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $title; ?></title>

  <!-- jQuery -->  
  <script src="<?php echo base_url(); ?>assets/js/jquery-3.0.0.min.js"></script>

  <!-- Bootstrap Core JavaScript -->
  <script src="<?php echo base_url(); ?>media/js/bootstrap.min.js"></script>

  <!--<title>SB Admin - Bootstrap Admin Template</title>-->

  <!-- Bootstrap Core CSS -->
  <link href="<?php echo base_url(); ?>media/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom CSS -->
  <link href="<?php echo base_url(); ?>media/css/sb-admin.css" rel="stylesheet">

  <!-- Morris Charts CSS -->
  <link href="<?php echo base_url(); ?>media/css/plugins/morris.css" rel="stylesheet">

  <!-- Custom Fonts -->
  <link href="<?php echo base_url(); ?>media/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
  <!--  -->

  <!-- Grocery crud css files start -->
  <?php if (isset($css_files)) {  
  foreach($css_files as $file): ?>
    <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
  <?php endforeach;} ?>
  
  <!-- Grocery crud css files end -->

  <style>
    .chosen-search input { width: 100% !important; }
    .form-input-box input{
      padding: 12px !important;
    }

    .ui-accordion-header{ background: #d4321d !important; }

    .floatL a { color:#fff !important; }

    .form-title-left {
      padding-top: 0px; 
    }
  </style>


</head>
<body>
  <div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="<?php echo base_url('index.php/home');?>">
          <img src="<?php echo base_url(); ?>assets/images/barfi_logo.png" style="height: 33px;margin-top: -3px;">
        </a>
      </div>
      <!-- Top Menu Items -->
      <ul class="nav navbar-right top-nav">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i><?php if(isset($_SESSION["full_name"])){echo "Welcome ".$_SESSION["full_name"];}else{echo "Welcome"." User";} ?><b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li>
              <a href="#"><i class="fa fa-fw fa-user"></i> Profile</a>
            </li>
            <li>
              <a href="#"><i class="fa fa-fw fa-envelope"></i> Inbox</a>
            </li>
            <li>
              <a href="#"><i class="fa fa-fw fa-gear"></i> Settings</a>
            </li>
            <li class="divider"></li>
            <li>
              <a href="<?php echo base_url(); ?>index.php/admin/logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
            </li>
          </ul>
        </li>
      </ul>
      
      <?php $this->load->view("admin/menu.php"); ?>
          <!-- /.navbar-collapse -->
      </nav>

  <div id="page-wrapper">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <!-- Page Heading -->
          <h1 class="page-header">
            <?php echo $header; ?>
            <small class="pull-right"><?php echo "Welcome ".ucfirst($this->session->userdata["full_name"])." !!!"; ?></small>
          </h1>

          <ol class="breadcrumb">
            <li>
              <i class="fa fa-dashboard"></i>
              <a href="<?php echo base_url(); ?>index.php/admin/Dashboard">Dashboard</a>
            </li>
            <?php if(isset($header) && $header != "Gallery" ){ ?>
            <li class="active">
              <i class="fa fa-edit"></i>
              <?php echo $header; ?>
            </li>
            <?php } else { ?>
              <li class="active">
                <i class="fa fa-edit"></i>
                <a href="../load">
                  Products
                </a>
              </li>
              <li class="active">
                <i class="fa fa-edit"></i>
                  <?php echo $header; ?>
              </li>
            <?php } ?>
          </ol>
        </div>
      </div>
      <?php
        if (isset($header) && $header == "Gallery") {
          ?>
          <div>
            <button type="button" class="btn-primary" onclick="window.history.back()">Back to list</button>
          </div><br><br>
          <?php
        }
          ?>
      <div>
        <?php if(isset($output)) {
          echo $output;
        }
        if (isset($header) && $header == "Dashboard") {
          $this->load->view("admin/dashboard");
        } 
        ?>
      </div>
    </div>
  </div>
<!--</div>-->
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->

<?php if(isset($js_files)) {
foreach($js_files as $file): ?>
    <script src="<?php echo $file; ?>"></script>
  <?php endforeach;} ?>

<!-- Morris Charts JavaScript -->
<script src="<?php echo base_url(); ?>media/js/plugins/morris/raphael.min.js"></script>
<script src="<?php echo base_url(); ?>media/js/plugins/morris/morris.min.js"></script>
<script src="<?php echo base_url(); ?>media/js/plugins/morris/morris-data.js"></script>

<script>
  var a = document.getElementById("field-product_req_quantity");
  a.setAttribute("onkeyup", "p_req()");
  function p_req() {
    var total = (document.getElementById("field-product_req_quantity").value)*(document.getElementById("prod_mrp").value);
    total = total-(total*(document.getElementById("p_discount").value)/100);
    total = total+(total*(document.getElementById("p_gst").value)/100);
   document.getElementById("prod_total").value ="RS "+ total+" /-";
  }
 
</script>

</body>

</html>