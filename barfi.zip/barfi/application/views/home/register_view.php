<!-- Including Header Start -->
<?php $this->load->view("home/header.php"); ?>
<body>
	

	
</body>

<?php $this->load->view("home/footer.php"); ?>

