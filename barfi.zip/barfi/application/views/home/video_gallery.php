<!-- Including Header Start -->
<?php $this->load->view("home/header.php"); ?>
<body>
<h2>Video gallery</h2>	

</body>
<?php $this->load->view("home/footer.php"); ?>