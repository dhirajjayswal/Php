<?php $this->load->view("home/header.php"); ?>

    <style type="text/css">
      .btn-login:hover,
      .btn-login:focus {
      color: #fff;
      background-color: #ea0e0ecc;
      border-color: #000000;
      }
      .btn-login {
      background-color: #f30f0fde;
      outline: none;
      color: #fff;
      font-size: 14px;
      height: auto;
      font-weight: normal;
      padding: 14px 0;
      text-transform: uppercase;
      border-color: #59B2E6;
      width: 50%;
    }
      .reset{
        width: 50%;
        margin: 0 auto;
        
        text-align: center;
      }
      

    </style>
<body>
  <div class="reset">
    <div class="panel-body">
  
        <div class="row">

              <div class="col-lg-12">

                <form id="login-form" action="<?php echo base_url()."home/retailer_reset_pwd" ?>" method="post" role="form" style="display: block;">
                  <div class="form-group">
                    <input type="text" name="new_pass" id="new_pass" class="form-control" placeholder="Reset your password" value="">
                    <input type="hidden" name="user_id" id="user_id" class="form-control" value="<?php echo(@$uid); ?>">
                  </div>
                  <div class="form-group">
                    <div class="row">
                      <div class="col-sm-6 col-sm-offset-3">
                        <input type="submit" name="reset" id="reset" tabindex="2" class="form-control btn btn-login" value="Reset">
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
     </div>

</body>

<?php $this->load->view("home/footer.php"); ?>