<!-- Including Header Start -->
<?php $this->load->view("home/header.php"); ?>
<style type="text/css">
	
.red{
    color:red;
    }
.form-area
{
    background-color: #FAFAFA;
	padding: 10px 40px 60px;
	margin: 10px 0px 60px;
	border: 1px solid GREY;
	}

</style>
<script type="text/javascript">
	$(document).ready(function(){ 
    $('#characterLeft').text('140 characters left');
    $('#message').keydown(function () {
        var max = 140;
        var len = $(this).val().length;
        if (len >= max) {
            $('#characterLeft').text('You have reached the limit');
            $('#characterLeft').addClass('red');
            $('#btnSubmit').addClass('disabled');            
        } 
        else {
            var ch = max - len;
            $('#characterLeft').text(ch + ' characters left');
            $('#btnSubmit').removeClass('disabled');
            $('#characterLeft').removeClass('red');            
        }
    });    
});
      function num(){          
         var val =getElementById('mobile').value
            if (/^\d{10}$/.test(val)) {
            // value is ok, use it
            } else {
            alert("Invalid number; must be ten digits")
            val.focus()
            return false
            }
            }

</script>
<body>
	<center>
	
<div class="container">
    <?php
    // print_r($status);exit();
    if (isset($status) && !empty($status)) {
        ?>
        <script>
            alert("<?php echo($status);$_POST=""; ?>");
            window.location.href = "<?php echo(base_url("Home/contact")); ?>";
        </script>
        <?php
     } 
      
     ?>
<div class="col-md-5">
    <div class="form-area">  
        <form method="post" action="<?php echo(base_url("Home/contact")); ?>">
        <br style="clear:both">
                    <h3 style="margin-bottom: 25px; text-align: center;">Contact Form</h3>
    				<div class="form-group">
						<input type="text" class="form-control" id="name" name="name" placeholder="Name" required>
					</div>
					<div class="form-group">
						<input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
					</div>
					<div class="form-group">
						<input type="text" class="form-control" id="mobile" name="mobile" placeholder="Mobile Number" required>
					</div>
					<div class="form-group">
						<input type="text" class="form-control" id="subject" name="subject" placeholder="Subject" required>
					</div>
                    <div class="form-group">
                    <textarea class="form-control" type="textarea" name="message" id="message" placeholder="Message" maxlength="140" rows="7"></textarea>
                        <span class="help-block"><p id="characterLeft" class="help-block ">You have reached the limit</p></span>                    
                    </div>
            
        <input type="submit" id="submit" name="submit" value="Submit Form" class="btn btn-primary pull-right" onclick="num()">
        <!-- <input type="submit" value="Submit Form"> -->
        </form>
    </div>
</div>
<div class="col-md-7">
	<iframe style="margin: 4px;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3766.092735776617!2d72.85600431447149!3d19.27833298697215!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b051fcaab3dd%3A0x57c87ca49cdf105f!2sOcean+Technosys!5e0!3m2!1sen!2sin!4v1516007284573" width="600" height="580" frameborder="0" style="border:0" allowfullscreen></iframe>
	</div>
</div>
</center>
</body>

<?php $this->load->view("home/footer.php"); ?>
