<!-- Including Header Start -->
<?php $this->load->view("home/header.php"); ?>
<body>
  <style type="text/css">
  .lr {
            width: 100%;
            height: 100%;
        }
        .thumb-grid {
          background-color: #fff;
        }
</style>
	
	 
    <div class="wrapper">
      <div class="row">
        
         <?php  
         if (isset($product_imgs)) {
          ?>
          
          <div id="thumbGrid" data-thumbgrid="true" data-effect="scaleIn" data-pagination="100" data-galleryeffectnext="scaleIn" data-galleryeffectprev="scaleOut" >
          <?php

          // print_r($product_imgs);
         	 foreach($product_imgs as $key=> $value) {
           ?>

           <img class="lr" src="<?php echo ($value['url']!="")?(base_url('/assets/uploads/').$value['url']):(base_url('/assets/images/default_product.jpg'));  ?>" data-highres="<?php echo base_url("assets/uploads/".$value["url"]); ?>" data-caption="<?php echo $value["title"]; ?>" width="250px" height="250px" style="margin: 0 auto;"  >

           <?php
         }
       } else {
         foreach($all_prod as $key=> $row) {

           ?>
        <?php //echo form_open('home/gallery'); ?>
        <form action="<?php echo(base_url('/home/gallery')); ?>" method="POST" style="height:0;margin-bottom: 0;">

        <div class="col-md-4 col-sm-6 animate">
          <div class="thumbnail ">
          	<img class="lr" src="<?php echo base_url("assets/uploads/".$row["image"]); ?>" data-highres="<?php echo base_url("assets/uploads/".$row["image"]); ?>" data-caption="<?php echo $row["name"]; ?>" width="300" height="300" />
                    <!-- <img src="images/Chrysanthemum.jpg"> -->
                    <div class="product1">
                        <span style="background-color: black; font-size: 19px;"><?php echo ucfirst($row["name"]) ;?></span><br>
                        <!-- <a href="<?php// echo base_url('home/products/'.($row["name"])); ?>"><i class="fa fa-fw fa-power-off"></i> View Details</a>  -->
                        <input type="hidden" name="p_id" value="<?php echo($row["id"]); ?>">
                        <input type="submit" class="btn" value="View More"/>
                    </div><br>
          </div><br>
        </div> <br> 
      </form>

          <?php //echo form_close(); ?>   
        <?php
           }
         }
        ?>

</div>
</div>
 <!-- <div class="col-md-12 product_page_links text-right">
          <?php echo $links; ?>
        </div> -->

  <script>

    jQuery(function () {
        jQuery("[data-thumbgrid]").thumbGrid();

//    customize
        jQuery("#effect").on("change",function(){
            var x = $(this).val();
            jQuery("#thumbGrid").data("effect", x);
        });

        jQuery("#delay").on("change",function(){
            var x = parseFloat($(this).val());
            jQuery("#thumbGrid").data("delay", x);
        });

        jQuery("#timing").on("change",function(){
            var x = parseFloat($(this).val());
            jQuery("#thumbGrid").data("timing", x);
        });
    });

</script>
</body>
<?php $this->load->view("home/footer.php"); ?>
