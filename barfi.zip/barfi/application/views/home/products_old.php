<!-- Including Header Start -->
<?php $this->load->view("home/header.php"); ?>
<?php $this->load->view("home/product_enlarge.php"); ?>
<!-- Including Header End -->

<!-- Product Filter Js -->
<script type="text/javascript" src=<?php echo base_url("assets/js/product_filter_level3.js"); ?>></script>

<!-- Product Filter CSS -->
<link rel="stylesheet" href="<?php echo base_url("assets/css/product_filter.css"); ?>" />

<!-- Section Start -->
<section>
  <!-- <div id='filters' class='sections'>
    <div class='filter-attributes'>
      <h4>Colour</h4>
      <input type='checkbox' name='colour' id='red' value='red' >Red</input>
      <input type='checkbox' name='colour' id='blue' value='blue' >Blue</input>
      <input type='checkbox' name='colour' id='green' value='green' >Green</input>
      <input type='checkbox' name='colour' id='yellow' value='yellow' >Yellow</input>
    </div>
    <div class='filter-attributes'>
      <h4>Size</h4>
      <input type='checkbox' name='size' id='large' value='large' >Large</input>
      <input type='checkbox' name='size' id='small' value='small' >Small</input>
      <input type='checkbox' name='size' id='medium' value='medium' >Medium</input>
      <input type='checkbox' name='size' id='xlarge' value='xlarge' >X-Large</input>
    </div>
    <div>
      <br>
      <input type='button' id='none' value='Clear all'></input>
    </div>
  </div> -->
  <style>
    .p_form_label {
      /*font-size: 12px;*/
      padding: 0;
      margin-left: 10px;
      /*vertical-align: middle;*/
    }
    .p_form_r {
      /*vertical-align: middle;*/
    }
  </style>

  <div class="row">
    <div class="col-md-12">
      <div class="col-md-2">
        <?php echo form_open('home/products'); ?>
        <nav>
          <ul class="main_cat">
            <li style="margin-bottom:10px;background:red;color: #fff;font-weight: 800;text-align: center;">
              Main Categories
            </li>
            <?php 
              if (isset($nav_data["main_categories"]) && (($nav_data["main_categories"])=="domestic")) {
            ?>
            <li>
              <input type="radio" value="domestic" name="main_categories" id="domestic" checked><label for="domestic" class="p_form_label">Domestic</label>
            </li>
            <?php }else{ ?>
            <li>
              <input type="radio" value="domestic" name="main_categories" id="domestic"><label for="domestic" class="p_form_label" >Domestic</label>
            </li>
            <?php } if (isset($nav_data["main_categories"]) && (($nav_data["main_categories"])=="international")) { ?>
            <li>
              <input type="radio" value="international" name="main_categories" id="international" checked><label for="international" class="p_form_label">International</label>
            </li>
            <?php } else { ?>
            <li>              
              <input type="radio" value="international" name="main_categories" id="international"><label for="international" class="p_form_label">International</label>
            </li>
            <?php } ?>
          </ul>
          <ul class="sub_cat">
            <li style="margin-bottom:10px;background:red;color: #fff;font-weight: 800;text-align: center;">
              Sub Categories
            </li>
            <?php foreach ($product_cat as $key => $value) {
              if (isset($nav_data["sub_category"][$key]) && (($nav_data["sub_category"][$key])==$value["name"])) {
            ?>
            <li>
              <input type="checkbox" value="<?php echo $value["name"]; ?>" name="sub_category[]" id="pens" checked><label for="pens" class="p_form_label"><?php echo $value["name"]; ?></label>
            </li>
            <?php } else { ?>
            <li>
              <input type="checkbox" value="<?php echo $value["name"]; ?>" name="sub_category[]" id="pens"><label for="pens" class="p_form_label"><?php echo $value["name"]; ?></label>
            </li>
            <?php
            }
          } ?>

          </ul>
          <ul class="colors">
            <li style="margin-bottom:10px;background:red;color: #fff;font-weight: 800;text-align: center;">
              Colors
            </li>
            <?php foreach ($product_colors as $key => $value) { 
              if (isset($nav_data["colors"][$key]) && (($nav_data["colors"][$key])==$value["name"])) {
            ?>
              <li>
                <input type="checkbox" value="<?php echo $value['name']; ?>" name="colors[]" id="colors" checked><label for="colors" class="p_form_label"><?php echo $value["name"]; ?></label>
              </li>
            <?php } else {
            ?>
              <li>
                <input type="checkbox" value="<?php echo $value['name']; ?>" name="colors[]" id="colors"><label for="colors" class="p_form_label"><?php echo $value["name"]; ?></label>
              </li>
            <?php
            }} ?>
          </ul>

          <ul class="brands">
            <li style="margin-bottom:10px;background:red;color: #fff;font-weight: 800;text-align: center;">
              Brands
            </li>
            <?php foreach ($product_brand as $key => $value) { ?>
            <li>
              <input type="checkbox" value="<?php echo $value['name']; ?>" name="brand_name[]" id="brand_name"><label for="brand_name" class="p_form_label"><?php echo $value["name"]; ?></label>
            </li>
            <?php } ?>            
          </ul>
          <div class="col-md-12">
            <div class="col-md-6">
              <input type="submit" value="Apply filter">
            </div>
            <!-- <div class="col-md-6">
              <input type="submit" value="Clear filter">              
            </div> -->
          </div>
        </nav>
        <?php echo form_close(); ?>   
      </div>
      
      <div class="col-md-10">
        <!-- <div class='sections'>
          <ul>
            <li class='grid-products large-boxes'>
              <h4>Product 1</h4>
              <div class='grid-variants' data-colour='red' data-size='large'>L</div>
              <div class='grid-variants' data-colour='red' data-size='small'>S</div>
            </li>
            <li class='grid-products large-boxes'>
              <h4>Product 2</h4>
              <div class='grid-variants' data-colour='red' data-size='medium'>M</div>
              <div class='grid-variants' data-colour='blue' data-size='small'>S</div>
              <div class='grid-variants' data-colour='green' data-size='large'>L</div>
            </li>
            <li class='grid-products large-boxes'>
              <h4>Product 3</h4>
              <div class='grid-variants' data-colour='yellow' data-size='medium'>M</div>
              <div class='grid-variants' data-colour='blue' data-size='large'>L</div>
              <div class='grid-variants' data-colour='yellow' data-size='large'>L</div>
              <div class='grid-variants' data-colour='green' data-size='medium'>M</div>
            </li>
            <li class='grid-products large-boxes'>
              <h4>Product 4</h4>
              <div class='grid-variants' data-colour='blue' data-size='medium'>M</div>
              <div class='grid-variants' data-colour='blue' data-size='large'>L</div>
              <div class='grid-variants' data-colour='red' data-size='small'>S</div>
              <div class='grid-variants' data-colour='green' data-size='medium'>M</div>
              <div class='grid-variants' data-colour='green' data-size='small'>S</div>
            </li>
          </ul>
      </div> -->
        <!-- <div class="col-md-3 product">
          <img src="<?php echo base_url("/assets/images/Desert.jpg"); ?>" width="100px" height="100px" style="margin: 0 auto;">
          <p>Name: Pens</p>
          <p>Description: Pens description</p>
          <button>ADD TO CART</button>
        </div> 
        <div class="col-md-3 product">
          <img src="<?php echo base_url("/assets/images/Desert.jpg"); ?>" width="100px" height="100px" style="margin: 0 auto;">
          <p>Name: Pens</p>
          <p>Description: Pens description</p>
          <button>ADD TO CART</button>
        </div> 
        <div class="col-md-3 product">
          <img src="<?php echo base_url("/assets/images/Desert.jpg"); ?>" width="100px" height="100px" style="margin: 0 auto;">
          <p>Name: Pens</p>
          <p>Description: Pens description</p>
          <button>ADD TO CART</button>
        </div>
        <div class="col-md-3 product">
          <img src="<?php echo base_url("/assets/images/Desert.jpg"); ?>" width="100px" height="100px" style="margin: 0 auto;">
          <p>Name: Pens</p>
          <p>Description: Pens description</p>
          <button>ADD TO CART</button>
        </div> -->


        <style>
          /* Product page links start */
          .product_page_links { margin-top: 20px; }
          .product_page_links a {
            border: 1pc solid #fff;
            padding: 5px;
          }
          /* Product page links end */

          /* product style start */
          .product {
            border: 1px solid #cecccc;
            padding: 10px;
            margin-top: 10px;
          }
          .product:hover,
          .product:active {
            border: 1px double red;
            cursor: pointer;
          }
          .product-img {
            margin-bottom: 10px;
          }
          /* product style end */
        </style>

        <?php foreach ($all_products as $key => $value) { ?>
          <div class="col-md-4">
            <div class="col-md-12 product">
              <div class="text-center product-img">
                <img src=<?php echo ($value['image']!="")?(base_url('/assets/uploads/').$value['image']):(base_url('/assets/images/default_product.jpg')); ?> width="160px" height="160px" style="margin: 0 auto;">
                     <div class="product-img1">
                       <!-- <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Product</button> -->
                       <img src="<?php echo base_url('/assets/images/information-button.png');  ?>" data-toggle="modal" data-target="#myModal">
                     </div>         
              </div>
              <p class="text-center"><?php echo $value['name']; ?></p>
              <div class="col-md-12" style="padding: 0;height: 50px;overflow: hidden;">
                <p><?php echo $value['description']; ?></p>
              </div>

              <div class="col-md-12" style="padding: 0">
                <div class="col-md-6">
                  <p>Colors:</p>                  
                </div>
                <div class="col-md-6">
                  <?php 
                    $colors = array('red','green','blue');
                    foreach ($colors as $key => $value) {
                      echo "<span style='display:inline-block;border-radius: 2px;margin-right:10px;vertical-align:middle;height:15px;width:15px;background:".$value."'></span>";
                    }
                  ?>
                </div>
              </div>
              <div class="col-md-12" style="padding: 0;margin-top: 10px;">
                <button style="width: 100%;background: red;color: #fff;">ADD TO CART</button>
              </div>
            </div>          
          </div>          
        <?php } ?>
        <div class="col-md-12">
          <?php //print_r($nav_data);exit();//if(isset($nav_data)){echo ($nav_data["sub_category"]);} ?>
        </div>
        <div class="col-md-12 product_page_links text-right">
          <?php echo $links; ?>
        </div>
        
      </div>    
    </div>    
  </div>
    
</section>

<!-- Section Ended -->

<!-- Including Footer Start -->
<?php $this->load->view("home/footer.php"); ?>
<!-- Including Footer End -->

<!-- <?php echo "<pre>";print_r($products); ?>