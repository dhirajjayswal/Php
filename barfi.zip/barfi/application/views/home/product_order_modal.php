<!-- Modal -->




<!-- <link href="assets/css/modalstyle.css" rel='stylesheet' type='text/css' media="all" /> -->
<!-- <link href='//fonts.googleapis.com/css?family=Exo+2:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'> -->
<!-- <link href='//fonts.googleapis.com/css?family=Titillium+Web:400,200,300,600,700,900' rel='stylesheet' type='text/css'> -->
    <!-- <script type="text/javascript">
       function compute(){

          var avl = document.getElementById('prod_avl_qty').value;
          var mrp = document.getElementById('prod_mrp').value;
          var req = document.getElementById('prod_req_qty').value;

          if (req<avl) {

            var total = mrp * req ;
            document.getElementById('total').innerHTMl = "Total Pay : Rs"+total;

          }
      }

    </script>
 -->
  <div class="modal fade" id="orderModal" role="dialog">
    <div class="modal-dialog" style="margin: 0 auto; width: 90%; top: 15px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <?php echo form_open('Orders/getOrder'); ?>
        
        <div class="modal-header">

          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Enquire Now</h4>
        </div>
        <div class="modal-body clearfix">
        <!-- Form Start -->

          <div class="row col-sm-12">
              <div class="col-sm-6">
                <div class="order">
                  <ul>

                    <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Product ID :
                      </label>
                      <input type="text" id="prod_id" name="prod_id" value="" class="form-control col-md-7" style="width: 60%;" readonly >
                    </li>
                    <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Product Name :
                      </label>
                      <input type="text" id="prod_name" name="prod_name" value="" class="form-control col-md-7" style="width: 60%;" readonly >
                    </li>
                    <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Brand :
                      </label>
                      <input type="text" value="" id="prod_brand" name="prod_brand" class="form-control col-md-7" style="width: 60%;" readonly>
                    </li>
                    <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Type :
                      </label>
                      <input type="text" id="prod_type" name="prod_type" class="form-control col-md-7" style="width: 60%;" readonly>
                    </li>
                    <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Product Code :
                      </label>
                      <input type="text" id="prod_code" name="prod_code"  class="form-control col-md-7" style="width: 60%;" readonly>
                    </li>
                    <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Description :
                      </label>
                      <input type="text" id="prod_desc" name="prod_desc"  class="form-control col-md-7" style="width: 60%;" readonly>
                    </li>  
                   <!--  <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Discount :
                      </label>
                      <input type="text" id="prod_disc" name="prod_disc"  class="form-control" style="width: 60%;" readonly />
                    </li>  -->     

                    <!--  <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Required Quantity :
                      </label>
                      <input type="number" id="prod_req_qty" name="prod_req_qty"  class="form-control" style="width: 60%;" onchange="compute()" required >
                    </li>  -->
                    <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Your Name :
                      </label>
                      <input type="text" id="prod_user" name="prod_user"  class="form-control" style="width: 60%;" required >
                    </li>    
                   <!--  <li class="col-md-12">
                      
                      <input type="hidden" id="prod_total" name="prod_total"  class="form-control" style="width: 70%;" value=""/>
                    </li>  -->      

                       

                    
                  </ul>

                </div>
              </div>
              <div class="col-sm-6">
                <div class="order">
                  <ul>
                    <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Category :
                      </label>
                      <input type="text" id="prod_cat" name="prod_cat" class="form-control col-md-7" style="width: 60%;" readonly>
                    </li>
                    <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Sub-Category :
                      </label>
                      <input type="text" id="prod_subcat" name="prod_subcat" class="form-control col-md-7" style="width: 60%;" readonly>
                    </li>
                    <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Colors :
                      </label>
                      <input type="text" id="prod_color" name="prod_color"  class="form-control col-md-7" style="width: 60%;" readonly>
                    </li>
                    <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Available Quantity :
                      </label>
                      <input type="text" id="prod_avl_qty" name="prod_avl_qty" class="form-control col-md-7" style="width: 60%;" readonly>
                    </li>
                    <!-- <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        MRP :
                      </label>
                      <input type="text" id="prod_mrp" name="prod_mrp"  class="form-control col-md-7" style="width: 60%;" readonly>
                    </li> -->
                     <!-- <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        GST :
                      </label>
                      <input type="text" id="prod_gst" name="prod_gst"  class="form-control" style="width: 60%;" readonly />
                    </li>    -->                
                    <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Contact :
                      </label>
                      <input type="text" id="prod_cntct" name="prod_cntct"  class="form-control col-md-7" style="width: 60%;" maxlength="10" required  >
                    </li>
                     <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Email :
                      </label>
                      <input type="email" id="user_email" name="user_email"  class="form-control" style="width: 60%;" required  >
                    </li>  
                    <!-- <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Address :
                      </label>
                      <input type="text" id="prod_addrs" name="prod_addrs"  class="form-control" style="width: 60%;" required  >
                    </li>    -->
                         
                    
                    <li class="col-md-12">
                      <label class="col-md-5" style="width: 40%;font-size: 16px;font-weight: bold;padding-left: 0;">
                        Comments :
                      </label>
                      <textarea id="prod_cmnts" name="prod_cmnts"  class="form-control" style="width: 60%;" ></textarea> 
                    </li>      
                  </ul>
                </div>
              </div>
            </div>

           
            <!-- form end -->
          </div>



          <div class="modal-footer">
            <div style="float: left;">
             <h4 id="total"></h4>
             <!-- <input type="text" name="total" id="total"> -->
             <script type="text/javascript">
                 function compute(){

                    var avl = document.getElementById('prod_avl_qty').value;
                    
                    var req = document.getElementById('prod_req_qty').value;
                    var gst = document.getElementById('prod_gst').value;
                    var discount = document.getElementById('prod_disc').value;
                    alert("avl is "+avl+""+" req is "+req+" req<=avl "+(parseInt(req)<=parseInt(avl)));

                        if ((parseInt(req)<=parseInt(avl)) && req!=0) {
                              var mrp = document.getElementById('prod_mrp').value;
                             var total = mrp * req ;
                             var discount = total-(total*(discount/100));
                             // var total_new = total - discount;
                             var total_gst = discount+(discount*(gst/100));
                             document.getElementById('total').innerHTML = "Total : Rs "+total+"/-"+"<br>Total with discount : Rs "+discount+"/-"+"<br>Total with discount and gst : Rs "+total_gst+"/-";

                             document.getElementById('prod_total').value = total_gst;
                        }
                        else {
                          alert("Sorry Product Out Of Stock");
                        }
                  }

             </script>

            
            </div>
            <input type="submit" class="btn btn-danger" value="Enquire Now"/>
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
           <?php echo form_close(); ?>
        </div>
      </div>      
    </div>
  </div>