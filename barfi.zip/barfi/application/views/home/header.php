<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>
   Barfi Pen
  </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="stylesheet" type = "text/css" href=<?php echo(base_url("assets/css/main.css")); ?>>

    <link rel="stylesheet" href="<?php echo(base_url('assets/css/bootstrap.min.css')); ?>">

    <link href='http://fonts.googleapis.com/css?family=Lekton|Lobster' rel='stylesheet' type='text/css'>

    
    <link rel="stylesheet" type="text/css" href="<?php echo(base_url('assets/css/thumbGrid.css')); ?>"/>
    <!-- <link rel="stylesheet" type="text/css" href="<?php echo(base_url('assets/css/jquery.mb.gallery.min.css?_v=1.3.1')); ?>"/> -->
    
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
<!--  -->

    <!-- SmartMenus core CSS (required) -->
    <link href="<?php echo(base_url('assets/css/sm-core-css.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- "sm-clean" menu theme (optional, you can use your own CSS, too) -->
    <link href="<?php echo(base_url('assets/css/sm-clean.css')); ?>" rel="stylesheet" type="text/css" />

  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
  <!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.js"></script> -->
  <!-- <script src="<?php echo(base_url('assets/js/jquery-3.0.0.min.js')); ?>"></script> -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  <script src="<?php echo(base_url('assets/js/bootstrap.min.js')); ?>"></script>
    <!-- <script src="<?php echo(base_url('assets/js/jquery.mb.gallery.js?_v=1.3.1')); ?>"></script> -->
    <script src="<?php echo(base_url('assets/js/jquery.mb.browser.min.js')); ?>"></script>
    <script src="<?php echo(base_url('assets/js/jquery.mb.thumbGrid.js')); ?>"></script>
    <script src="<?php echo(base_url('assets/js/jquery.mb.CSSAnimate.min.js')); ?>"></script>
    <script>
      <?php 
      if (@$this->session->flashdata('login_msg') && ($this->session->flashdata('login_msg')!='') && (strcmp($this->session->flashdata('login_msg'),'Please Login!!!')!== 0) && (strcmp($this->session->flashdata('login_msg'),'Wrong Username or Password')!== 0)) {
        // echo($this->session->flashdata('login_msg'));
        ?>
        
        alert("<?php echo($this->session->flashdata('login_msg')); ?>");
        <?php
        $this->session->set_flashdata('login_msg', '');
      }
      ?>
    </script>
  <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->
  <style>
  .badge-notify{
    background:#d4321d;;
    position:relative;
    top: -20px;
    right: 10px;
  }
  .my-cart-icon-affix {
    position: fixed;
    z-index: 999;
  }
    * {box-sizing:border-box}
body {font-family: Verdana,sans-serif;}
.mySlides {display:none}

/* Slideshow container */
.slideshow-container {
  /*max-width: 1000px;*/
  position: relative;
  margin: 0;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 13px;
  width: 13px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}

@media only screen and (max-width: 500px) {
  .searchblock input{width: 150px; margin-bottom: 5px;}
}

@media only screen and (max-width: 992px) {
  .join {/*width: 200px; float: none;*/text-align: left;}
}

@media only screen and (max-width: 500px) {
  .join input[type="email"]{width: 100%;}
  .join input[type="submit"]{margin-top: 5px;}
}

@media only screen and (max-width: 500px) {
  .social {display: inline-block; height: 20%;}
}

nav li a{
  font-size: 15px;
}

  </style>

  

    
</head>
<body>
  <div class=" up">
      <div class="container wrapper clearfix">
        <ul>
          <li href="#">
            HELP
          </li>
          <li href="#">
            CONTACT
          </li>
          <li href="#">
            DELIVERY INFORMATION 
          </li>
        </ul>  
        <div class="upright">
            CALL US: 0322352782
        </div>
      </div>
    </div>
      <!-- Container Start -->
<div class="container">
  
  <!-- Wrapper Start -->
<div class="wrapper">

    <div class="wrapper clearfix">
    <!-- <div class="wrapper"> -->
    <header>
      
        <div class="logo">
          <a href="#">
            <img src=<?php echo(base_url("assets/images/barfi_logo.png")); ?> style="height: 80px;">
          </a>
        
        <div class="header_right">
          <div class="reg">
           <!--  <?php if (isset($_SESSION["logged_in"]) && $_SESSION["logged_in"] == 1) { ?>
              <span style="border:none;"><?php echo "Welcome ".$_SESSION['user_name']; ?></span>
              <a href="<?php echo(base_url("home/retailer_logout")); ?>" > LOGOUT </a>
            <?php
            } else { ?>
              <a href="<?php echo(base_url("home/retailer_login")); ?>" > LOGIN </a>
            <?php
            }
             ?> -->
            <div style="float: right; cursor: pointer;">
        <!-- <div class="page-header">
    
      <div style="float: right; cursor: pointer;">
        <span class="glyphicon glyphicon-shopping-cart my-cart-icon"><span class="badge badge-notify my-cart-badge"></span></span>
      </div>
    
  </div> -->
      </div>
          </div>

               <div class="searchblock">
            
              <input type="text" name="search"  placeholder="search....">
              <!-- <input type="submit" name=""> -->
            <button class="search"></button>
          </div>
          
        </div>
        </div>
      
    </header>
    <!-- </div> -->
    </div>
    <nav class="wrapper navbar navbar-inverse nav1">
  <div class="">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <!-- <a class="navbar-brand" href="#">WebSiteName</a> -->
    </div>

    <!-- <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav nav2">
        <li class="acti"><a href=<?php echo(base_url("home")); ?>>HOME</a></li>
        <li><a href=<?php echo base_url("home/about_us"); ?>>ABOUT US</a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">PRODUCTS<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Domestic</a></li>
            <li><a href="#">International</a></li>            
          </ul>
        </li>
        <li><a href="#">GALLERY</a></li>
        <li><a href="#">CONTACT US</a></li>
      </ul>
      <!-- <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
        <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul> -->
    <!-- </div> --> 
    <div class="collapse navbar-collapse" id="myNavbar">
    <nav id="main-nav" style="background: #fff;">
      <!-- Sample menu definition -->
      <ul id="main-menu" style="border-radius: unset;z-index: 2; " class="sm sm-clean" data-smartmenus-id="15081546362683533">
        <li><a style="font-size: 16px;" href="<?php echo(base_url("home")); ?>">Home</a></li>
        <li><a style="font-size: 16px;" href="<?php echo base_url("home/about_us"); ?>">About Us</a></li>
        <li><a style="font-size: 16px;" href="<?php echo(base_url("home/products")); ?>" class="has-submenu" id="sm-15081546362683533-7" aria-haspopup="true" aria-controls="sm-15081546362683533-8" aria-expanded="false">Products<!-- <span class="sub-arrow"></span> --></a>
          <ul class="" style="" id="sm-15081546362683533-8" role="group" aria-hidden="true" aria-labelledby="sm-15081546362683533-7" aria-expanded="false">
            <!-- <li><a href="#" class="disabled">Disabled menu item</a></li> -->
            <!-- <li><a href="#">Dummy item</a></li> -->
            <li><a style="font-size: 16px;" href="#" class="has-submenu" id="sm-15081546362683533-9" aria-haspopup="true" aria-controls="sm-15081546362683533-10" aria-expanded="false">Domestic<span class="sub-arrow"></span></a>
              <ul class="" style="" id="sm-15081546362683533-10" role="group" aria-hidden="true" aria-labelledby="sm-15081546362683533-9" aria-expanded="false">
                <!-- <li><a href="#">A pretty long text to test the default subMenusMaxWidth:20em setting for the sub menus</a></li> -->
                <li><a href="#">Product 1</a></li>
                <li><a href="#">Product 2</a></li>
                <li><a href="#">Product 3</a></li>
                <li><a href="#">Product 4</a></li>
                 <!-- <li><a href="#" class="has-submenu" id="sm-15081546362683533-11" aria-haspopup="true" aria-controls="sm-15081546362683533-12" aria-expanded="false">more...<span class="sub-arrow"></span></a>
                  <ul class="" style="" id="sm-15081546362683533-12" role="group" aria-hidden="true" aria-labelledby="sm-15081546362683533-11" aria-expanded="false">
                    <li><a href="#">Dummy item</a></li>
                    <li><a href="#" class="current">A 'current' class item</a></li>
                    <li><a href="#">Dummy item</a></li>
                    <li><a href="#" class="has-submenu" id="sm-15081546362683533-13" aria-haspopup="true" aria-controls="sm-15081546362683533-14" aria-expanded="false">more...<span class="sub-arrow"></span></a>
                      <ul class="" style="" id="sm-15081546362683533-14" role="group" aria-hidden="true" aria-labelledby="sm-15081546362683533-13" aria-expanded="false">
                        <li><a href="#">subMenusMinWidth</a></li>
                        <li><a href="#">10em</a></li>
                        <li><a href="#">forced.</a></li>
                      </ul>
                    </li>
                  </ul>
                </li> --> 
                
              </ul>
            </li>
            <li><a style="font-size: 16px;" href="#" class="has-submenu" id="sm-15081546362683533-9" aria-haspopup="true" aria-controls="sm-15081546362683533-10" aria-expanded="false">International<span class="sub-arrow"></span></a>
              <ul class="" style="" id="sm-15081546362683533-10" role="group" aria-hidden="true" aria-labelledby="sm-15081546362683533-9" aria-expanded="false">
                <!-- <li><a href="#">A pretty long text to test the default subMenusMaxWidth:20em setting for the sub menus</a></li> -->
                <li><a href="#">Product 5</a></li>
                <li><a href="#">Product 6</a></li>
                <li><a href="#">Product 7</a></li>
                <li><a href="#">Product 8</a></li>
                 <!-- <li><a href="#" class="has-submenu" id="sm-15081546362683533-11" aria-haspopup="true" aria-controls="sm-15081546362683533-12" aria-expanded="false">more...<span class="sub-arrow"></span></a>
                  <ul class="" style="" id="sm-15081546362683533-12" role="group" aria-hidden="true" aria-labelledby="sm-15081546362683533-11" aria-expanded="false">
                    <li><a href="#">Dummy item</a></li>
                    <li><a href="#" class="current">A 'current' class item</a></li>
                    <li><a href="#">Dummy item</a></li>
                    <li><a href="#" class="has-submenu" id="sm-15081546362683533-13" aria-haspopup="true" aria-controls="sm-15081546362683533-14" aria-expanded="false">more...<span class="sub-arrow"></span></a>
                      <ul class="" style="" id="sm-15081546362683533-14" role="group" aria-hidden="true" aria-labelledby="sm-15081546362683533-13" aria-expanded="false">
                        <li><a href="#">subMenusMinWidth</a></li>
                        <li><a href="#">10em</a></li>
                        <li><a href="#">forced.</a></li>
                      </ul>
                    </li>
                  </ul>
                </li> --> 
                
              </ul>
            </li>
          </ul>
        </li>
        <!-- <li><a href="http://www.smartmenus.org/about/" class="has-submenu" id="sm-15081546362683533-1" aria-haspopup="true" aria-controls="sm-15081546362683533-2" aria-expanded="false">About Us<span class="sub-arrow"></span></a>
          <ul class="" style="" id="sm-15081546362683533-2" role="group" aria-hidden="true" aria-labelledby="sm-15081546362683533-1" aria-expanded="false">
            <li><a href="http://www.smartmenus.org/about/introduction-to-smartmenus-jquery/">Introduction to SmartMenus jQuery</a></li>
            <li><a href="http://www.smartmenus.org/about/themes/">Demos + themes</a></li>
            <li><a href="http://vadikom.com/about/#vasil-dinkov">The author</a></li>
            <li><a href="http://www.smartmenus.org/about/vadikom/" class="has-submenu" id="sm-15081546362683533-3" aria-haspopup="true" aria-controls="sm-15081546362683533-4" aria-expanded="false">The company<span class="sub-arrow"></span></a>
              <ul class="" style="" id="sm-15081546362683533-4" role="group" aria-hidden="true" aria-labelledby="sm-15081546362683533-3" aria-expanded="false">
                <li><a href="http://vadikom.com/about/">About Vadikom</a></li>
                <li><a href="http://vadikom.com/projects/">Projects</a></li>
                <li><a href="http://vadikom.com/services/">Services</a></li>
                <li><a href="http://www.smartmenus.org/about/vadikom/privacy-policy/">Privacy policy</a></li>
              </ul>
            </li>
          </ul>
        </li> -->
        <!-- <li><a href="http://www.smartmenus.org/download/">Download</a></li> -->
        <li><a style="font-size: 16px;" href="<?php echo base_url("home/gallery"); ?>" class="has-submenu" id="sm-15081546362683533-5" aria-haspopup="true" aria-controls="sm-15081546362683533-6" aria-expanded="false">Gallery<!-- <span class="sub-arrow"></span> --></a>
          <ul class="" style="" id="sm-15081546362683533-6" role="group" aria-hidden="true" aria-labelledby="sm-15081546362683533-5" aria-expanded="false">
            <li><a style="font-size: 16px;" href="<?php echo base_url("home/gallery"); ?>">Photo Gallery</a></li>
            <li><a style="font-size: 16px;" href="<?php echo base_url("home/video_gallery"); ?>">Video Gallery</a></li>
          </ul>
        </li>
        <li><a style="font-size: 16px;" href="<?php echo base_url("home/contact"); ?>">Contact Us</a></li>
        
        <!-- <li><a href="#" class="has-submenu" id="sm-15081546362683533-15" aria-haspopup="true" aria-controls="sm-15081546362683533-16" aria-expanded="false">Mega menu<span class="sub-arrow"></span></a>
          <ul class="mega-menu" style="" id="sm-15081546362683533-16" role="group" aria-hidden="true" aria-labelledby="sm-15081546362683533-15" aria-expanded="false">
            <li>
              <!-- The mega drop down contents -->
              <!-- <div style="width:400px;max-width:100%;">
                <div style="padding:5px 24px;">
                  <p>This is a mega drop down test. Just set the "mega-menu" class to the parent UL element to inform the SmartMenus script. It can contain <strong>any HTML</strong>.</p>
                  <p>Just style the contents as you like (you may need to reset some SmartMenus inherited styles - e.g. for lists, links, etc.)</p>
                </div>
              </div>
            </li>
          </ul>
        </li> -->
      </ul>
    </nav>
  </div>
  </div>
</nav>
