<!-- Including Header Start -->
<?php $this->load->view("home/header.php"); ?>
<!-- Including Header End -->

<!-- Section Start -->
<section>
<div class="wrapper clearfix">
  <dir class="row">
    <h2 class="col-md-12">About Us</h2>    
  </dir>

  <div class="row">
    
    <div class="col-md-8">
      <h3>Who we are?</h3>
       <!-- <div style="border-top: 2px solid grey"></div> -->
      <p style="text-align: justify;">
        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
      </p>
    </div>
    <div class="col-md-4">
      <img class="img-responsive" style="height: 300px;border: " src= <?php echo base_url("assets/images/lighthouse.jpg"); ?> alt="">
    </div>
  </div>

  <div class="row">
    
    <div class="col-md-8 center" style="text-align: justify;">
      <h3>What we do?</h3>
      <!-- <div style="border-top: 2px solid grey"></div> -->
      <p>
        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
      </p>
    </div>
    
  </div>
  

</div>
</section>
<!-- Section Ended -->

<!-- Including Footer Start -->
<?php $this->load->view("home/footer.php"); ?>
<!-- Including Footer End -->