<Including Header Start >
<?php $this->load->view("home/header.php"); ?>
<!-- Including Header End -->
<style type="text/css">
  .animate{
      opacity:0.9 ;
  }
  .animate:hover {
      
       opacity:1;
          -webkit-transform: scale(1.05);
          -ms-transform: scale(1.05);
          transform: scale(1.05);

}    

</style>
<!-- Section Start -->
<section>

  <!-- <button class="btn btn-danger my-cart-btn" id="my-cart-btn" data-id="1" data-name="product 1" data-summary="summary 1" data-price="10" data-quantity="1" data-image="<?php //echo base_url("assets/cart/images/img_1.png"); ?>" >Add to Cart</button> -->

      <div class="row">
        <div class="col-md-12">
          <a class="thumbnail1">
                    <!-- <img src="images/desert.jpg" style="height: 260px; width: 1080px;"> -->

                    <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img class="img-responsive" src=<?php echo(base_url("assets/images/lighthouse.jpg")); ?> style="height: 350px; width: 100%; ">
  <div class="text"></div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img class="img-responsive" src=<?php echo(base_url("assets/images/desert.jpg")); ?> style="height: 350px; width: 100%; ">
  <div class="text"></div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img class="img-responsive" src=<?php echo(base_url("assets/images/koala.jpg")); ?> style="height: 350px; width: 100%; ">
  <div class="text"></div>
</div>

</div>
<br>

<div style="display:none;text-align:center;">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>

<script>

var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex> slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 2500); // Change image every 2.5 seconds
}
</script>

               

                </a>
        </div>
          <div class="col-md-8 col-xm-12 col-sm-6 pad1" >
            <div class="thumbnail bimg img-responsive">
                        <div class="transbox">
                            <p> Sets of </p>
                            <p> Barfi Grip Ball Pen at 35% off! </p>
                            <a href="#">
                                Enquire Now!
                            </a>
                            <!-- <button class="btn btn-danger my-cart-btn" data-id="1" data-name="product 1" data-summary="summary 1" data-price="10" data-quantity="1" data-image=<?php //echo base_url("assets/cart/images/img_1.png"); ?>>Add to Cart</button> -->
              <!-- <img class="img-responsive" src="images/koala.jpg" style="height: 300px; width: 710px;"> -->
                        </div>
                    </div>
          </div>
          <div class="col-md-4 col-xm-12 col-sm-6">
            <div class="thumbnail bgimg img-responsive">
                    <div class="trans">

                    
                    <p>sets of barfi gel pen</p>
                    <p>@ 20% off!</p>
                    <a href="#"> Enquire Now! 
                    </a>

                    </div>
                    <!--
                    <form>
                        <input type="submit" name="" value="Enquire Now!">
                    </form>
                    -->
                 
                    <!-- <img class="img-responsive" src="images/lighthouse.jpg" style="height: 300px; width: 340px;"> -->
                    
                    </div>   
          </div>  
      </div>
     <!--  <?php //echo "<pre>"; print_r($product_cat);?>
      <?php  foreach($product_cat as $key=> $row) {


        ?>

        <h1><?php echo $row["id"] ;?></h1>
        <h1><?php echo $row["name"] ;?></h1>
        <h1><?php echo $row["desc"] ;?></h1>
        <h1><?php echo $row["added_by"] ;?></h1>
        <h1><?php echo $row["date"] ;?></h1>
        <?php
      }
        ?> -->
 
    <div class="products">
      <p>  OUR PRODUCTS  </p>
    </div>
    <div class="wrapper">
      <div class="row">
         <?php  foreach($product_cat as $key=> $row) { ?>

       <!--  <?php //echo form_open('home/products'); ?> -->

         <form action="<?php echo(base_url('home/products')); ?>" method="POST" style="margin-bottom: 0;">
             
        <div class="col-md-4 col-sm-6 animate">
          <div class="thumbnail   " style="background: #eeeeee url('<?php echo base_url('assets/uploads/'.$row['image']);  ?> ') no-repeat; width: 100%;height:100%; background-size: cover;">
                    <div class="product1">
                        <h4><?php echo $row["name"] ;?></h4>
                        <input type="hidden" name="p_cat" value="<?php echo($row["name"]); ?>">
                        <input type="submit" class="btn" value="View Details"/>
                    </div>
          </div>
        </div> 
        </form>  
          <?php //echo form_close(); ?>   
        <?php
           }
        ?>

        <!-- <div class="col-md-4 col-sm-6">
           
          <div class="thumbnail productbg2">
          <div class="product2">
            <!-- <img src="images/hydrangeas.jpg"> -->
          <!-- <p>Pencil</p>
          <a href="<?php echo base_url(); ?>home/products/Pencils"><i class="fa fa-fw fa-power-off"></i>View Details</a>
          </div>
          </div>
        </div>                        
        <div class="col-md-4 col-sm-6">
          <div class="thumbnail productbg3">
            <!-- <img src="images/jellyfish.jpg"> -->
         <!--  <div class="product3">
              <p>Eraser</p>
              <a href="<?php echo base_url(); ?>home/products/Eraser"><i class="fa fa-fw fa-power-off"></i>View Details</a>
          </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-6">
          
          <div class="thumbnail productbg4">
            <img src="images/koala.jpg"> -->
         <!--  <div class="product4">
              <p>Gel pen</p>
              <a href="#">Enquire Now!</a>
          </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-6">
          
          <div class="thumbnail productbg5">
            <!-- <img src="images/lighthouse.jpg"> -->
         <!--  <div class="product5">
              <p>Sets of 5 pen just at Rs.100/-</p>
              <a href="#">Enquire Now!</a>
          </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-6">
          
          <div class="thumbnail productbg6">
          <!-- <!--   <!-- <img src="images/desert.jpg"> -->
          <!-- <div class="product6"> -->
              <!-- <p>10 sets of gel pen just at Rs.900/-</p> -->
          <!--     <a href="#">Enquire Now!</a> --> 
          <!-- </div> --> 
       <!--    </div>
        </div>
      </div>
    </div> --> 
   
<!-- Section Ended -->

<!-- Including Footer Start --> 
<?php $this->load->view("home/footer.php"); ?>
<!-- Including Footer End -->
<?php
// session_start();
$counter_name = "countlog.txt";

// Check if a text file exists. If not create one and initialize it to zero.
if (!file_exists($counter_name)) {
  $f = fopen($counter_name, "w");
  fwrite($f,"0");
  fclose($f);
}

// Read the current value of our counter file
$f = fopen($counter_name,"r");
$counterVal = fread($f, filesize($counter_name));
fclose($f);

// Has visitor been counted in this session?
// If not, increase counter value by one
if(!isset($_SESSION['hasVisited'])){
  $_SESSION['hasVisited']="yes";
  $counterVal++;
  $f = fopen($counter_name, "w");
  fwrite($f, $counterVal);
  fclose($f); 
}

// echo "You are visitor number $counterVal to this site";
?>
<!-- <?php //echo "<pre>";print_r($products); ?>