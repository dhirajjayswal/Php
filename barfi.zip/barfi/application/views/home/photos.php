<!-- Including Header Start -->
<?php $this->load->view("home/header.php"); ?>
<body>
	<style type="text/css">
	.lr {
            width: 100%;
            height: 100%;
        }
        .thumb-grid {
        	background-color: #fff;
        }
</style>

	<!-- <?php foreach ($all_products as $key => $value) { ?>
          <div class="col-md-4 ">
            <div class="col-md-12 product ">
              <div class="text-center product-img">
                <img src=<?php echo ($value['image']!="")?(base_url('/assets/uploads/').$value['image']):(base_url('/assets/images/default_product.jpg')); ?> width="250px" height="250px" style="margin: 0 auto;"> 
                <?php
           }
        ?> -->

         <div class="col-md-12 wrapper clearfix">        	

	        <div id="thumbGrid" data-thumbgrid="true" data-effect="scaleIn" data-delay="60" data-timing="800" data-pagination="100" data-galleryeffectnext="scaleIn" data-galleryeffectprev="scaleOut" style="background-color: none;">
	            <!-- <img class="lr" src="<?php echo base_url('assets/images/Koala.jpg'); ?>" data-highres="<?php echo base_url('assets/images/Koala.jpg'); ?>" data-caption="test caption" /> -->
				<?php 
					foreach ($all_prod as $key => $value) {
						?>
						<img class="lr" src="<?php echo ($value['image']!="")?(base_url('/assets/uploads/').$value['image']):(base_url('/assets/images/default_product.jpg'));  ?>" data-highres="<?php echo base_url("assets/uploads/".$value["image"]); ?>" data-caption="<?php echo $value["name"]; ?>" width="250px" height="250px" style="margin: 0 auto;">

							<!-- <img class="lr" src="<?php echo base_url("assets/uploads/".$value["image"]); ?>" data-highres="<?php echo base_url("assets/uploads/".$value["image"]); ?>" data-caption="<?php echo $value["name"]; ?>"/> -->

						<?php
					}
				?>
			</div>
		</div>
		


				<script>

    jQuery(function () {
        jQuery("[data-thumbgrid]").thumbGrid();

//    customize
        jQuery("#effect").on("change",function(){
            var x = $(this).val();
            jQuery("#thumbGrid").data("effect", x);
        });

        jQuery("#delay").on("change",function(){
            var x = parseFloat($(this).val());
            jQuery("#thumbGrid").data("delay", x);
        });

        jQuery("#timing").on("change",function(){
            var x = parseFloat($(this).val());
            jQuery("#thumbGrid").data("timing", x);
        });
    });

</script>
	
</body>
<?php $this->load->view("home/footer.php"); ?>

