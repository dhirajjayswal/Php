<!-- Including Header Start -->
<?php $this->load->view("home/header.php"); ?>
<?php $this->load->view("home/product_enlarge.php"); ?>
<?php $this->load->view("home/product_order_modal.php"); ?>
<style>
  .no-bold {
    font-weight: normal;
  }
</style>
<!-- Including Header End -->

<!-- Product Filter Js -->
<script type="text/javascript" src=<?php echo base_url("assets/js/product_filter_level3.js"); ?>></script>

<!-- Product Filter CSS -->
<link rel="stylesheet" href="<?php echo base_url("assets/css/product_filter.css"); ?>" />

<!-- Section Start -->
<section>
  <!-- <div id='filters' class='sections'>
    <div class='filter-attributes'>////
      <h4>Colour</h4>
      <input type='checkbox' name='colour' id='red' value='red' >Red</input>
      <input type='checkbox' name='colour' id='blue' value='blue' >Blue</input>
      <input type='checkbox' name='colour' id='green' value='green' >Green</input>
      <input type='checkbox' name='colour' id='yellow' value='yellow' >Yellow</input>
    </div>
    <div class='filter-attributes'>
      <h4>Size</h4>
      <input type='checkbox' name='size' id='large' value='large' >Large</input>
      <input type='checkbox' name='size' id='small' value='small' >Small</input>
      <input type='checkbox' name='size' id='medium' value='medium' >Medium</input>
      <input type='checkbox' name='size' id='xlarge' value='xlarge' >X-Large</input>
    </div>
    <div>
      <br>
      <input type='button' id='none' value='Clear all'></input>
    </div>
  </div> -->
  <style>
    .p_form_label {
      /*font-size: 12px;*/
      padding: 0;
      margin-left: 0px;
      /*vertical-align: middle;*/
    }
    .p_form_r {
      /*vertical-align: middle;*/
    }
    .effect:hover{
         border-style:  solid;
    border-color:  grey;
    }

  </style>

  <div class="row ">
    <div class="col-md-12">
      <div class="col-md-2 ">
        <?php echo form_open('home/products'); ?>
        <nav>
          <!-- <ul class="main_cat">
            <li style="margin-bottom:10px;background:#d4321d;;color: #fff;font-weight: 800;text-align: center;">
              Main Categories
            </li>
            <?php 
              if (isset($nav_data["main_categories"]) && (($nav_data["main_categories"])=="domestic")) {
            ?>
            <li>
              <input type="radio" value="domestic" name="main_categories" id="domestic" checked><label for="domestic" class="p_form_label">Domestic</label>
            </li>
            <?php }else{ ?>
            <li>
              <input type="radio" value="domestic" name="main_categories" id="domestic"><label for="domestic" class="p_form_label" >Domestic</label>
            </li>
            <?php } if (isset($nav_data["main_categories"]) && (($nav_data["main_categories"])=="international")) { ?>
            <li>
              <input type="radio" value="international" name="main_categories" id="international" checked><label for="international" class="p_form_label">International</label>
            </li>
            <?php } else { ?>
            <li>              
              <input type="radio" value="international" name="main_categories" id="international"><label for="international" class="p_form_label">International</label>
            </li>
            <?php } ?>
          </ul> -->
          <ul class="cat ">
            <li style="font-weight:bold; padding-bottom: 5px;">
              CATEGORIES
            </li>
            <?php foreach ($product_cat as $key => $value) {
              // print_r($nav_data);
              $match = 0;
              if (isset($nav_data["category"])) {
                # code...
                foreach ($nav_data["category"] as $key1 => $value1) {
                  if ($value['name']==$value1) {
                    $match = 1;
                    // echo $value['name']." and ".$value1."<br>";
                  }
                }
              }

              if ($match == 1) {

                // echo "Selected ".$value["name"];
                ?>
                <li class="">
                  <input type="checkbox" value="<?php echo $value["name"]; ?>" name="category[]" id="<?php echo "cat".$value['id']; ?>" style="margin: 10px;" checked><label for="<?php echo "cat".$value['id']; ?>" class="p_form_label"><?php echo $value["name"]; ?></label>
                </li>
                <?php
              } else {
                // echo "Not Selected ".$value["name"];
                ?>
                <li style="padding-left: 5px;">
                  <input type="checkbox" value="<?php echo $value['name']; ?>" name="category[]" id="<?php echo "cat".$value['id']; ?>" style="margin: 10px;" ><label for="<?php echo "cat".$value['id']; ?>" class="p_form_label no-bold"><?php echo $value["name"]; ?></label>
                </li>
                <?php
              }


              
            ?>
            
            <?php
            
          } ?>
          <div style="border-bottom: 2px solid #e4e4e4; padding-top: 10px;"></div>

          </ul>
          <ul class="sub_cat">
            <li style="font-weight:bold; padding-bottom: 5px;">
              SUB-CATEGORIES
            </li>
            <?php foreach ($product_subcat as $key => $value) {
              // print_r($nav_data);
              $match = 0;
              if (isset($nav_data["subcategory"])) {
                # code...
                foreach ($nav_data["subcategory"] as $key1 => $value1) {
                  if ($value['name']==$value1) {
                    $match = 1;
                    // echo $value['name']." and ".$value1."<br>";
                  }
                }
              }

              if ($match == 1) {
                // echo "Selected ".$value["name"];
                 /* Pagination Start */
      
                    // $this->load->model("home_model");

                    // $p_count = $this->home_model->get_products_count();
                    // $config['base_url'] = base_url()."home/products";
                    // $config['total_rows'] = $p_count;
                    // $config['per_page'] = 3;
                    // $config["cur_tag_open"] = "<a style='text-decoration:none;font-weight:800;font-size:20px;'>";
                    // $config["cur_tag_close"] = "</a>";
                    // $config['next_link'] = 'Next';
                    // $config['prev_link'] = 'Prev';
                    // $config["uri_segment"] = 3;
                    // $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                    // $where = $_REQUEST;
                    // $all_products["all_products"] = $this->home_model->get_products($config['per_page'],$page,$where);
                    // $all_products["product_cat"] = $this->home_model->get_product_cat();
                    // $all_products["product_subcat"] = $this->home_model->get_product_subcat();
                    // $all_products["product_colors"] = $this->home_model->get_product_colors();
                    // $all_products["product_brand"] = $this->home_model->get_product_brand();
                    // $all_products["nav_data"] = $where;
                              

                    // $this->pagination->initialize($config);

                    // $all_products["links"] = $this->pagination->create_links();
                    // /* Pagination End */
                    // $this->output_to_view('home/products.php',$all_products);
                ?>
                <li>
                  <input type="checkbox" value="<?php echo $value["name"]; ?>" name="subcategory[]" id="<?php echo "subcat".$value['id']; ?>" style="margin: 10px;" checked><label for="<?php echo "subcat".$value['id']; ?>" class="p_form_label"><?php echo $value["name"]; ?></label>
                </li>
                <?php
              } else {
                // echo "Not Selected ".$value["name"];
                ?>
                <li>
                  <input type="checkbox" value="<?php echo $value['name']; ?>" name="subcategory[]" id="<?php echo "subcat".$value['id']; ?>" style="margin: 10px;" ><label for="<?php echo "subcat".$value['id']; ?>" class="p_form_label no-bold"><?php echo $value["name"]; ?></label>
                </li>
                <?php
              }


              
            ?>
            
            <?php
            
          } ?>

          <div style="border-bottom: 2px solid #e4e4e4; padding-top: 10px;"></div>


          </ul>
          <ul class="colors">
            <li style="font-weight:bold; padding-bottom: 5px;">
              COLORS
            </li>
            <?php foreach ($product_colors as $key => $value) { 
              if (isset($nav_data["colors"][$key]) && (($nav_data["colors"][$key])==$value["name"])) {
            ?>
              <li>
                <input type="checkbox" value="<?php echo $value['name']; ?>" name="colors[]" id="colors" style="margin: 10px;" checked><label for="colors" class="p_form_label"><?php echo $value["name"]; ?></label>
              </li>
            <?php } else {
            ?>
              <li>
                <input type="checkbox" value="<?php echo $value['name']; ?>" name="colors[]" id="colors" style="margin: 10px;"><label for="colors" class="p_form_label no-bold"><?php echo $value["name"]; ?></label>
              </li>
            <?php
            }} ?>
            <div style="border-bottom: 2px solid #e4e4e4; padding-top: 10px;"></div>

          </ul>

          <ul class="brands">
            <li style="font-weight:bold; padding-bottom: 5px;">
              BRANDS
            </li>
            <?php foreach ($product_brand as $key => $value) { 
                if (isset($nav_data["brand_name"][$key]) && (($nav_data["brand_name"][$key])==$value["name"])) {
            ?>
            <li>
              <input type="checkbox" value="<?php echo $value['name']; ?>" name="brand_name[]" id="<?php echo("brand_name_".$key); ?>" style="margin: 10px; border-radius: 45px;" checked><label for="<?php echo("brand_name_".$key); ?>" class="p_form_label"><?php echo $value["name"]; ?></label>
            </li>
            <?php } else { ?>
            <li>
              <input class="checkbox-circle" type="checkbox" value="<?php echo $value['name']; ?>" name="brand_name[]" id="<?php echo("brand_name_".$key); ?> " style="margin: 10px; border-radius: 45px; "  ><label for="<?php echo("brand_name_".$key); ?>" class="p_form_label no-bold"><?php echo $value["name"]; ?></label>
            </li>
            <?php 
            }
            }
            ?>  
            <div style="border-bottom: 2px solid #e4e4e4; padding-top: 10px;"></div>          
          </ul>
          <div class="col-md-12">
            <div class="col-md-6" style="padding-top: 15px;">
              <input type="submit" value="Apply filter">
            </div>
            <!-- <div class="col-md-6">
              <input type="submit" value="Clear filter">              
            </div> -->
          </div>
        </nav>
        <?php echo form_close(); ?>   
      </div>
      
      <div class="col-md-10">
        <!-- <div class='sections'>
          <ul>
            <li class='grid-products large-boxes'>
              <h4>Product 1</h4>
              <div class='grid-variants' data-colour='red' data-size='large'>L</div>
              <div class='grid-variants' data-colour='red' data-size='small'>S</div>
            </li>
            <li class='grid-products large-boxes'>
              <h4>Product 2</h4>
              <div class='grid-variants' data-colour='red' data-size='medium'>M</div>
              <div class='grid-variants' data-colour='blue' data-size='small'>S</div>
              <div class='grid-variants' data-colour='green' data-size='large'>L</div>
            </li>
            <li class='grid-products large-boxes'>
              <h4>Product 3</h4>
              <div class='grid-variants' data-colour='yellow' data-size='medium'>M</div>
              <div class='grid-variants' data-colour='blue' data-size='large'>L</div>
              <div class='grid-variants' data-colour='yellow' data-size='large'>L</div>
              <div class='grid-variants' data-colour='green' data-size='medium'>M</div>
            </li>
            <li class='grid-products large-boxes'>
              <h4>Product 4</h4>
              <div class='grid-variants' data-colour='blue' data-size='medium'>M</div>
              <div class='grid-variants' data-colour='blue' data-size='large'>L</div>
              <div class='grid-variants' data-colour='red' data-size='small'>S</div>
              <div class='grid-variants' data-colour='green' data-size='medium'>M</div>
              <div class='grid-variants' data-colour='green' data-size='small'>S</div>
            </li>
          </ul>
      </div> -->
        <!-- <div class="col-md-3 product">
          <img src="<?php echo base_url("/assets/images/Desert.jpg"); ?>" width="100px" height="100px" style="margin: 0 auto;">
          <p>Name: Pens</p>
          <p>Description: Pens description</p>
          <button>ADD TO CART</button>
        </div> 
        <div class="col-md-3 product">
          <img src="<?php echo base_url("/assets/images/Desert.jpg"); ?>" width="100px" height="100px" style="margin: 0 auto;">
          <p>Name: Pens</p>
          <p>Description: Pens description</p>
          <button>ADD TO CART</button>
        </div> 
        <div class="col-md-3 product">
          <img src="<?php echo base_url("/assets/images/Desert.jpg"); ?>" width="100px" height="100px" style="margin: 0 auto;">
          <p>Name: Pens</p>
          <p>Description: Pens description</p>
          <button>ADD TO CART</button>
        </div>
        <div class="col-md-3 product">
          <img src="<?php echo base_url("/assets/images/Desert.jpg"); ?>" width="100px" height="100px" style="margin: 0 auto;">
          <p>Name: Pens</p>
          <p>Description: Pens description</p>
          <button>ADD TO CART</button>
        </div> -->


        <style>
          /* Product page links start */
          .product_page_links { margin-top: 20px; }
          .product_page_links a {
            border: 1pc solid #fff;
            padding: 5px;
          }
          /* Product page links end */

          /* product style start */
          .product {
            border: 1px solid #cecccc;
            padding: 10px;
            margin-bottom: 30px;
          }
          .product:hover,
          .product:active {
            /*border: 1px double red;*/
            cursor: pointer;
             box-shadow: 7px 5px #ececec;
          }
          .product-img {
            margin-bottom: 10px;
          }
          /* product style end */
        </style>
        <script>
          // $(document).ready(function(){
          function p_getdetails(id) {
            // alert("id passed is "+id);
            
            $.ajax({
              url: '<?php echo base_url()."index.php/home/get_prod_info"; ?>',
              method: 'POST',
              data: {'id': id},
              success: function(result){
                //var myObj = JSON.parse(result);
                var res = JSON.parse(result);

                $("#jssor_1").empty();
                $("#jssor_1").append('<!-- Loading Screen --><div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);"><img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="<?php echo base_url("assets/images/img/spin.svg");?>"/></div><div id="p_gall_imgs" data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:980px;height:380px;overflow:hidden;"></div><!-- Thumbnail Navigator --><div data-u="thumbnavigator" class="jssort101" style="position:absolute;left:0px;bottom:0px;width:980px;height:100px;background-color:#000;" data-autocenter="1" data-scale-bottom="0.75"><div data-u="slides"><div data-u="prototype" class="p" style="width:190px;height:90px;"><div data-u="thumbnailtemplate" class="t"></div><svg viewbox="0 0 16000 16000" class="cv"><circle class="a" cx="8000" cy="8000" r="3238.1"></circle><line class="a" x1="6190.5" y1="8000" x2="9809.5" y2="8000"></line><line class="a" x1="8000" y1="9809.5" x2="8000" y2="6190.5"></line></svg></div></div></div><!-- Arrow Navigator --><div data-u="arrowleft" class="jssora106" style="width:55px;height:55px;top:162px;left:30px;" data-scale="0.75"><svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;"><circle class="c" cx="8000" cy="8000" r="6260.9"></circle><polyline class="a" points="7930.4,5495.7 5426.1,8000 7930.4,10504.3 "></polyline><line class="a" x1="10573.9" y1="8000" x2="5426.1" y2="8000"></line></svg></div><div data-u="arrowright" class="jssora106" style="width:55px;height:55px;top:162px;right:30px;" data-scale="0.75"><svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;"><circle class="c" cx="8000" cy="8000" r="6260.9"></circle><polyline class="a" points="8069.6,5495.7 10573.9,8000 8069.6,10504.3 "></polyline><line class="a" x1="5426.1" y1="8000" x2="10573.9" y2="8000"></line></svg></div>');


                /*Adding images to slider*/
                for (var i = res.p_images.length - 1; i >= 0; i--) {
                  $("#p_gall_imgs").append('<div><img data-u="image" src="<?php echo base_url("assets/uploads/'+res.p_images[i].url+'"); ?>" /><img data-u="thumb" src="<?php echo base_url("assets/uploads/thumb__'+res.p_images[i].url+'"); ?>" /></div>');
                }


                /* Adding info into product description */
                $("#p_name").html(res.p_info[0].name);
                $("#p_brand").html(res.p_info[0].brand_name);
                $("#p_type").html(res.p_info[0].type);
                $("#product_code").html(res.p_info[0].product_code);
                $("#description").html(res.p_info[0].description);

                $("#p_cat").html(res.p_info[0].category);
                $("#p_subcat").html(res.p_info[0].sub_category);
                $("#p_colors").html(res.p_info[0].colors);
                $("#quantity").html(res.p_info[0].quantity);
                $("#mrp").html(res.p_info[0].mrp);

                /* Initialising Slider */
                jssor_1_slider_init();
                // alert(result);
                $('#myModal').modal('show');
              }
              
            });
            
          }
          // });
          $(document).ready(function () {
            $(".enquire_btn").on("click",function () {
              var id = $(this).attr("pid");
              // alert("id is "+id);
              $.ajax({
                url: '<?php echo base_url()."index.php/home/get_prod_info"; ?>',
                method: 'POST',
                data: {'id': id},
                success: function(result){
                  //var myObj = JSON.parse(result);
                  var res = JSON.parse(result);
                  // alert(res.p_info[0].name);
                  $("#prod_id").val(res.p_info[0].id);
                  $("#prod_name").val(res.p_info[0].name);
                  $("#prod_brand").val(res.p_info[0].brand_name);
                  $("#prod_type").val(res.p_info[0].type);
                  $("#prod_code").val(res.p_info[0].product_code);
                  $("#prod_desc").val(res.p_info[0].description);
                  $("#user_email").val(res.p_info[0].email);

                  //$("#prod_cat").val(res.p_info[0].category);
                  //$("#prod_subcat").val(res.p_info[0].sub_category);
                 // $("#prod_color").val(res.p_info[0].colors);
                  $("#prod_avl_qty").val(res.p_info[0].quantity);
                  //$("#prod_mrp").val(res.p_info[0].mrp);
                  //$("#prod_gst").val(res.p_info[0].gst);
                 // $("#prod_disc").val(res.p_info[0].discount);
                 // $("#prod_total").val(res.p_info[0].total);

                  $('#orderModal').modal('show');
                }
              });
            });
          });

        </script>

        <?php //echo "<pre>";print_r($all_products); ?>
          <?php 
          if (isset($status)) {
            ?>
            <script>
              alert("<?php echo($status); ?>");
              window.location.href = "<?php echo(base_url("Home/products")); ?>";
            </script>
            <?php
          } 
          
        ?>


        <?php foreach ($all_products as $key => $value) { ?>
          <div class="col-md-4 ">
            <div class="col-md-12 product ">
              <div class="text-center product-img">
                <img src=<?php echo ($value['image']!="")?(base_url('/assets/uploads/').$value['image']):(base_url('/assets/images/default_product.jpg')); ?> width="250px" height="250px" style="margin: 0 auto;"> 
                <div class="product-img1">
                  <!-- <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Product</button> -->
                     <img src="<?php echo base_url('/assets/images/zoom-tools.png');  ?>" onclick="p_getdetails(<?php echo $value['id']; ?>)" >
                </div>             
              </div>
              <p class="text-center"><?php echo ucfirst($value['name']); ?></p>
              <!-- <button onclick="p_getdetails(<?php echo $value['id']; ?>)">details</button> -->
              <div class="col-md-12" style="padding: 0;height: 50px;overflow: hidden;">
                <p style="text-align: center;"><?php echo ucfirst($value['description']); ?></p>
              </div>

              <div class="col-md-12" style="padding: 0">
                <!-- <div class="col-md-6">
                  <p  style=" position: relative;left: 20%;">Colors:</p>                  
                </div> -->
                <div class="col-md-6" style="width: 70px;">
                  <p style="text-align: center;">Colors:</p>
                </div>
                <div class="col-md-6">
                  <?php 
                    $colors = explode(",", $value['colors']);
                    foreach ($colors as $key => $v) {
                      echo "<span style='display:inline-block;border-radius: 7px;margin-right:10px;vertical-align:middle;height:15px;width:15px;    position: relative;right: 40 %;background:".$v."'></span>";
                    }
                  ?>
                <!-- </div> -->
                </div>
              </div>
              <div class="col-md-12" style="padding: 0;margin-top: 10px;">
                <!-- <button style="width: 100%;background: red;color: #fff;">ADD TO CART</button> -->
                <button class="enquire_btn" pid="<?php echo $value['id']; ?>" style="width: 50%;background: #d4321d;color: #fff;position: relative;left: 25%; padding: 8px; border: none;">ENQUIRE NOW </button>
              </div>
            </div>          
          </div>          
        <?php } ?>
        <div class="col-md-12">
          <?php //print_r($nav_data);exit();//if(isset($nav_data)){echo ($nav_data["sub_category"]);} ?>
        </div>
        <div class="col-md-12 product_page_links text-right">
          <?php echo $links; ?>
        </div>
        
      </div>    
    </div>    
  </div>
    
</section>


<!-- Section Ended -->

<!-- Including Footer Start -->
<?php $this->load->view("home/footer.php"); ?>
<!-- Including Footer End -->

<!-- <?php //echo "<pre>";print_r($products); ?>