<!-- Including Header Start -->
<?php $this->load->view("home/header.php"); ?>
<style type="text/css">
	.lr {
            width: 100%;
            height: 100%;
        }
        .thumb-grid {
        	background-color: #fff;
        }
</style>

<body>
	<!-- <div id="thumbGallery"
             class="thumbGallery"

             data-thumbGallery="true"

             data-nav_effect="slide_horizontal"
             data-nav_delay="100"
             data-nav_timing="1000"
             data-nav_show="true"
             data-nav_delay_inverse="1"
             data-nav_pagination="6"

             data-gallery_cover="true"
             data-gallery_effect="slide_horizontal"
             data-gallery_fullscreenw="90%"
             data-gallery_fullscreenh="100%"
        > -->
        <div class="col-md-12 wrapper clearfix">        	

	        <div id="thumbGrid" data-thumbgrid="true" data-effect="scaleIn" data-delay="60" data-timing="800" data-pagination="100" data-galleryeffectnext="scaleIn" data-galleryeffectprev="scaleOut" style="background-color: none;">
	            <img class="lr" src="<?php echo base_url('assets/images/Koala.jpg'); ?>" data-highres="<?php echo base_url('assets/images/Koala.jpg'); ?>" data-caption="test caption" />
				<?php 
					foreach ($all_prod as $key => $value) {
						?>
							<img class="lr" src="<?php echo base_url("assets/uploads/".$value["image"]); ?>" data-highres="<?php echo base_url("assets/uploads/".$value["image"]); ?>" data-caption="<?php echo $value["name"]; ?>"/>

						<?php
					}
				?>
				<!-- <nav class="thumbGridNav"><a idx="0" class="indexEl sel">1</a><a idx="1" class="indexEl">2</a><a idx="2" class="indexEl">3</a><a idx="3" class="indexEl">4</a></nav>                         -->
	        </div>
        <?php //exit(); ?>
					<!-- <nav class="thumbGridNav">
	        <?php 
	   //      $c= count($all_prod);
				// while ($c%6!=0) {
					?>

						<a idx="<?php echo $key; ?>" class="indexEl sel"><?php echo $key+1; ?></a>						
					<?php
				// }
			?>
					</nav> -->
        </div>

        

	<!-- <div class="wrapper col-md-12 clearfix"> -->
		
	<?php 
	//echo "<pre>";print_r($all_prod);
	/*foreach ($all_prod as $key => $value) {
		?>
		<div class="col-md-3" style="padding: 5px; ">
			<img width="300" height="300" src="<?php echo base_url("assets/uploads/".$value["image"]); ?>">
			<p style="padding: 10px; margin: 5px auto;"><?php echo $value["name"]; ?></p>
		</div>
		<?php
	}*/
	?>
	<!-- </div> -->
	<!-- <script>

    var isIframe = function() {
        var a = !1;
        try {
            self.location.href != top.location.href && ( a = !0 )
        } catch ( b ) {
            a = !0
        }
        return a
    };
    if ( !isIframe() ) {
        var logo = $( "<a href='http://pupunzi.com/#mb.components/components.html' style='position:absolute;top:0;z-index:1000'><img id='logo' border='0' src='http://pupunzi.com/images/logo.png' alt='mb.ideas.repository'></a>" );
        $( "#wrapper" ).prepend( logo ), $( "#logo" ).fadeIn()
    }

    /* Initialize the mbGallery */
   var myGallery = jQuery("#thumbGallery").mbGallery();

    /* customizer */
    jQuery("#effect").on("change",function(){
        var x = $(this).val();
        myGallery.data("nav_effect", x);

    });

    jQuery("#delay").on("change",function(){
        var x = parseFloat($(this).val());
        myGallery.data("nav_delay", x);
    });

    jQuery("#timing").on("change",function(){
        var x = parseFloat($(this).val());
        myGallery.data("nav_timing", x);
    });

    if(jQuery.isMobile){
        jQuery("body").css({marginBottom: 140})
    }

</script> -->
<script>

    jQuery(function () {
        jQuery("[data-thumbgrid]").thumbGrid();

//    customize
        jQuery("#effect").on("change",function(){
            var x = $(this).val();
            jQuery("#thumbGrid").data("effect", x);
        });

        jQuery("#delay").on("change",function(){
            var x = parseFloat($(this).val());
            jQuery("#thumbGrid").data("delay", x);
        });

        jQuery("#timing").on("change",function(){
            var x = parseFloat($(this).val());
            jQuery("#thumbGrid").data("timing", x);
        });
    });

</script>
</body>
<?php $this->load->view("home/footer.php"); ?>
