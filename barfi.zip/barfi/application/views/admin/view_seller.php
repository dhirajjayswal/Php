
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    VIEW SELLER
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="<?php echo base_url(); ?>index.php/admin/index">Dashboard</a>
                    </li>
                    <li class="active">
                        <i class="fa fa-edit"></i> Retailers
                    </li>
                </ol>
            </div>
        </div>
        <div class="row">  <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-money fa-fw"></i>Seller List</h3>
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>Company Name</th>
                                        <th>Contact Person</th>
                                        <th>Email</th>
                                        <th>Contact Number</th>
                                        <th>Pincode</th>
                                        <th>location</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    foreach ($get_seller as $val) {
                                        ?>
                                        <tr>
                                            <td><?php echo $val->c_name; ?></td>
                                            <td><?php echo $val->s_name; ?></td>
                                            <td><?php echo $val->email; ?></td>
                                            <td><?php echo $val->number; ?></td>
                                            <td><?php echo $val->pincode; ?></td>
                                            <td><?php echo $val->location; ?></td>
                                            <td><a href="<?php echo base_url(); ?>index.php/admin/edit_seller?id=<?php echo $val->id; ?>"><i title="Edit" class="fa fa-edit"></i></a>
                                                <a href="<?php echo base_url(); ?>index.php/admin/delete_seller?id=<?php echo $val->id; ?>"><i title="Delete" class="fa fa-trash"></i></a></td>

                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>