<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
<div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="<?php echo base_url();?>index.php/admin/dashboard"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>
<!--                    <li>
                        <a href="charts.html"><i class="fa fa-fw fa-bar-chart-o"></i> Charts</a>
                    </li>
                    <li>
                        <a href="tables.html"><i class="fa fa-fw fa-table"></i> Tables</a>
                    </li>-->                    
                    <!-- <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo"><!-- <i class="fa fa-fw fa-arrows-v"></i>  --><!--RETAILERS <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="<?php echo base_url();?>index.php/admin/seller_register"><i class="fa fa-fw fa-edit"></i>REGISTER SELLER</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url();?>index.php/admin/view_seller">VIEW SELLERS</a>
                            </li>                            
                        </ul>
                    </li> -->
                    
                    <!-- Subadmin Start -->
                    <?php if (isset($_SESSION["user_role"]) && $_SESSION["user_role"] == 'a') { ?>
                    <!-- <li>
                        <a href="<?php echo base_url();?>index.php/Subadmin/load">SUB-ADMIN</a>
                    </li> -->
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#subadmin"></i> SUB-ADMIN<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="subadmin" class="collapse">
                            <li>
                              <a href="<?php echo base_url();?>index.php/Subadmin/index/add"></i>CREATE</a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>index.php/Subadmin">LIST</a>
                            </li>
                        </ul>
                    </li>
                    <?php } ?>
                    <!-- Subadmin Start -->

                    <!-- Salesman Start -->
                    <?php if (isset($_SESSION["user_role"]) && (($_SESSION["user_role"] == 'a')||($_SESSION["user_role"] == 'sa')) ) { ?>                
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#salesteam_menu"></i> SALES TEAM <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="salesteam_menu" class="collapse">
                            <li>
                              <a href="<?php echo base_url();?>index.php/Salesteam/index/add"></i>CREATE</a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>index.php/Salesteam">LIST</a>
                            </li>
                        </ul>
                    </li>
                    <?php } ?>
                    <!-- Salesman End -->

                    <!-- Retailers Start -->
                    <?php if (isset($_SESSION["user_role"]) && (($_SESSION["user_role"] == 'a')||($_SESSION["user_role"] == 'sa')||($_SESSION["user_role"] == 'st')) ) { ?>                  
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#retailers_menu"></i> RETAILERS <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="retailers_menu" class="collapse">
                            <li>
                              <a href="<?php echo base_url();?>index.php/Retailers/index/add"></i>CREATE</a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>index.php/Retailers">LIST</a>
                            </li>
                        </ul>
                    </li>
                    <?php } ?>
                    <!-- Retailers End -->
                    


                    <!-- Product start -->
                    
                     <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#product_menu"></i> PRODUCT <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="product_menu" class="collapse">

                          <?php if (isset($_SESSION["user_role"]) && (($_SESSION["user_role"] == 'a')||($_SESSION["user_role"] == 'sa')) ) { ?>
                            <!-- Only for Admin and Subadmin -->
                            <li>
                              <a href="<?php echo base_url();?>index.php/Products/category"></i>PRODUCT CATEGORY</a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>index.php/Products/subcategory"></i>PRODUCT SUB-CATEGORY</a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>index.php/Products/brand">PRODUCT BRAND</a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>index.php/Products/colors">PRODUCT COLORS</a>
                            </li>

                          <?php } ?>

                            <li>
                              <a href="<?php echo base_url();?>index.php/Products/load">PRODUCT</a>
                            </li>
                        </ul>
                    </li>
                    <!-- Product end -->

                    <?php if (isset($_SESSION["user_role"]) && (($_SESSION["user_role"] == 'a')||($_SESSION["user_role"] == 'sa')) ) { ?>
                    <li>
                      <a href="<?php echo base_url();?>index.php/Packages/load"><!-- <i class="fa fa-fw fa-arrows-v"></i> -->PACKAGES<!-- <i class="fa fa-fw fa-caret-down"></i> --></a>                        
                    </li>
                     <li>
                      <a href="<?php echo base_url();?>index.php/home/load"><!-- <i class="fa fa-fw fa-arrows-v"></i> -->CONTACT US<!-- <i class="fa fa-fw fa-caret-down"></i> --></a>                        
                    </li>
                    <?php } ?>
                    <?php if (isset($_SESSION["user_role"]) && (($_SESSION["user_role"] == 'a')||($_SESSION["user_role"] == 'sa')||($_SESSION["user_role"] == 'st')) ) { ?>
                    <li>
                      <a href="<?php echo base_url();?>index.php/Enquiries/load"><!-- <i class="fa fa-fw fa-arrows-v"></i> -->ENQUIRIES<!-- <i class="fa fa-fw fa-caret-down"></i> --></a>                        
                    </li>
                    <?php } ?>

                    <li>
                      <a href="<?php echo base_url();?>index.php/Orders/load"><!-- <i class="fa fa-fw fa-arrows-v"></i> -->ORDER MANAGEMENT<!-- <i class="fa fa-fw fa-caret-down"></i> --></a>
                    </li>
                    
                    <!-- <li>
                        <a>OFFERS</a>
                    </li>
                    <li>
                        <a>REPORTS</a>
                    </li> -->
                    <li>
                        <a href="<?php echo base_url();?>index.php/admin/logout">LOGOUT</a>
                    </li>
<!--                    <li>
                        <a href="bootstrap-elements.html"><i class="fa fa-fw fa-desktop"></i> Bootstrap Elements</a>
                    </li>
                    <li>
                        <a href="bootstrap-grid.html"><i class="fa fa-fw fa-wrench"></i> Bootstrap Grid</a>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo"><i class="fa fa-fw fa-arrows-v"></i> Dropdown <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="#">Dropdown Item</a>
                            </li>
                            <li>
                                <a href="#">Dropdown Item</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="blank-page.html"><i class="fa fa-fw fa-file"></i> Blank Page</a>
                    </li>
                    <li>
                        <a href="index-rtl.html"><i class="fa fa-fw fa-dashboard"></i> RTL Dashboard</a>
                    </li>-->
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

