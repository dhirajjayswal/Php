<!DOCTYPE html>
<html lang="en" style="width:100%; height:100%;">
    <head>
        <title>Barfi</title>
        <meta name=viewport content="width=device-width, initial-scale=1">
        <meta http-equiv=Content-Type content="text/html; charset=utf-8"/>
        <link href="<?php echo base_url(); ?>media/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>media/css/sb-admin.css" rel="stylesheet">

        <style type="text/css">
            .flashError{
                color:red;
            }

            @media only screen and (max-width: 500px) {
        body {
        background-image: url('assets/images/adminbg.jpg') !important;
         }
        }

        </style>
    </head>
    <body style="background:url(<?php echo base_url('assets/images/background.jpg'); ?>); background-size:cover;margin: 0;">
        <div class="container">
       <div style="width:60%;  padding:10px; margin:70px auto;box-shadow:0px 0px 0px 5px rgba(0,0,0,0.15);background:#fff; height: 320px ">
        <div>

            <img src="<?php echo base_url('assets/images/barfi_logo.png');?>"" width="100" height="50">
            <h3 style="text-align: center; " >Login</h3>
            <?php if ($this->session->flashdata('login')) { ?>
                <p class='flashError'> <?php echo $this->session->flashdata('login') ?> </p>
            <?php }
            ?>
            <form role = "form" autocomplete = "off" action = "<?php echo base_url(); ?>index.php/admin/verify_login" method = "post" id = "login_form">
                <div class = "form-group input-group">
                <span class = "input-group-addon">@</span>
                <input type = "text" name = "username" class = "form-control" title="Please enter your username" placeholder = "Email id" required>
                </div>
                <div class = "form-group input-group">
                <span class = "input-group-addon ">@</span>
                <input type = "password" name = "password" class = " glyphicon glyphicon-user form-control" title="Please enter your password" placeholder = "Password" required>
                </div>
                <input type = "submit" id="sub" value="Submit" class = "btn btn-default" style="border-color:#251e1e;background-color:#368bc7; color: #fbf9f9" onclick="">
               
            </form>
        </div>
        </div>
    </div>
        <!--jQuery -->
        <script src = "<?php echo base_url(); ?>media/js/jquery.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="<?php echo base_url(); ?>media/js/bootstrap.min.js"></script>
        <script>
            $(document).ready(function() {
                $('.flashError').fadeOut(1000);
            });

         
         </script>
         <script >
             
               // function myFunction() {
               //      var txt;
               //      if (confirm("Do you want to change Password ?")) {
                     // txt = "<a href="<?php  //echo base_url('home/retailer_reset_pwd') ?>"></a>"; 
               //      } else {
               //          txt = "You pressed Cancel!";
               //      }
                    
               //  }
         </script>
    </body>
</html>