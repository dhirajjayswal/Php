<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Forms
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a>
                    </li>
                    <li class="active">
                        <i class="fa fa-edit"></i> Forms
                    </li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <form role="form" action="<?php echo base_url(); ?>index.php/admin/add_seller" method="post">
                    <div class="form-group">
                        <label>Company Name*</label>
                        <input type="text" id="c_name" name="c_name" class="form-control" placeholder="Enter text" required>
                    </div>
                    <div class="form-group">
                        <label>Contact Person Name</label>
                        <input type="text" id="s_name" name="s_name" class="form-control" placeholder="Enter text">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input id="email" name="email" class="form-control" placeholder="Enter text">
                    </div>
                    <div class="form-group">
                        <label>Contact Person Number*</label>
                        <input type="text" id="number" name="number" class="form-control" placeholder="Enter text" required>
                    </div>
                    <div class="form-group">
                        <label>Address*</label>
                        <!--<input id="add" name="add" class="form-control" placeholder="Enter text">-->
                        <textarea id="add" name="add" class="form-control" placeholder="Enter text" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Pincode*</label>
                        <input type="text" id="pincode" name="pincode" class="form-control" placeholder="Enter text" required>
                    </div>
                    <div class="form-group">
                        <label>Location*</label>
                        <input type="text" id="location" name="location" class="form-control" placeholder="Enter text" required>
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Submite">
                        <input type="button" value="Cancle">
                    </div>
                </form>
            </div>
            <div class="col-lg-6"> 
            </div>
        </div>
    </div>
</div>