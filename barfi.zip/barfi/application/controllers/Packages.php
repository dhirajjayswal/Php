<?php 

class Packages extends CI_Controller {

  public function __construct() {

    parent::__construct();

    $this->load->database();
    $this->load->helper('url');
    $this->load->library('Grocery_CRUD');
    $this->load->library('session');
  }

  public function load()
  {
    // echo "<pre>";
  //   print_r($this->session->userdata);
  //   echo "string".$this->session->user_name;exit();
    $crud = new grocery_CRUD();
    $crud->set_theme('datatables');
    $crud->set_subject("Packages");
    $crud->set_table('tbl_packages');
    //$crud->where('added_by',$this->session->userdata["user_name"]);

    /* SETTING FIELDS */
    
    

    /* Setting dropdown fields */
    // $crud->field_type('type','dropdown',array('Ink Pen' => 'Ink Pen', 'Ball Pen' => 'Ball Pen'));
    // $crud->field_type('status','dropdown',array('active' => 'active', 'inactive' => 'inactive'));
    // $crud->field_type('shippable','dropdown',array('yes' => 'yes', 'no' => 'no'));

    /* Setting Multiselect fields */
    // $crud->field_type('packages','multiselect',$my_packages);
    // $crud->field_type('uploader_id', 'hidden', $this->session->user_name);
    // $crud->field_type('upload_date', 'hidden', date("d-m-Y"));
    // $crud->field_type('time', 'hidden', date("d-m-Y"));

    /* Adding Hidden Data to Fields */
    $crud->field_type('added_by', 'hidden', $this->session->userdata["user_name"]);
    $crud->field_type('date', 'hidden', date("d-m-Y"));

    $crud->columns('id','name','quantity','price');
    // $crud->set_rules('name','Name test','numeric');
    if (isset($this->session->userdata["user_role"]) && ($this->session->userdata["user_role"] == 'sa' || $this->session->userdata["user_role"] == 'st' || $this->session->userdata["user_role"] == 'rt')) {
      $crud->unset_delete();
    }
    $output = $crud->render();
    $output1 = array('title' => 'Barfi | Packages', 'header' => 'Packages');
    $output = array_merge((array) $output, $output1);

    $this->load->view('admin_template.php', $output);
  }
}