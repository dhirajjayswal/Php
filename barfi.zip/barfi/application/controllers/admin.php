<?php

if (!defined('BASEPATH')){
    exit('No direct script access allowed');
}

class admin extends CI_Controller {

    public function __construct() {

        parent::__construct();

        $this->load->database();
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->model('admin_model');
        $this->load->model('home_model');
        $this->load->library('session');
    }

    public function index() {
        $this->load->view('admin/login');
    }

    public function verify_login() {
        $data = $this->admin_model->check_user();
        $data1 = $this->home_model->retailer_login();
        if ($data):
            if ($data1->otp == 1) {
              redirect('home/retailer_reset_pwd');
            } else {
                redirect('admin/dashboard');
            }
        else:

            $this->session->set_flashdata('login', 'Wrong Username or Password');
            $this->load->view('admin/login');
        endif;

    }

    public function logout() {
        if ($this->session->userdata('user_name')):
            $this->session->sess_destroy();
            $this->load->view('admin/login');
        else:
            $this->load->view('admin/login');
        endif;
    }

    public function dashboard() {
        $output['content'] = 'dashboard';
        $output['title'] = 'Dashboard';
        $output['header'] = 'Dashboard';
        $output['seller_count'] = $this->admin_model->get_seller_count();
        $output['order_count'] = $this->admin_model->get_order_count();
        $output['product_count'] = $this->admin_model->get_product_count();
        $this->load->view('admin_template', $output);
    }

    public function seller_register() {
        $data['content'] = 'seller_register';
        $data['title'] = 'seller_register';
        $this->load->view('template/admin_template', $data);
    }

    public function add_seller() {
        $this->admin_model->add_seller();
        redirect('admin/seller_register');
    }

    public function view_seller() {
        $data['content'] = 'view_seller';
        $data['title'] = 'view_seller';
        $data['get_seller'] = $this->admin_model->get_seller();

        $this->load->view('template/admin_template', $data);
    }

    public function delete_seller() {
        $id = $_REQUEST['id'];
        $this->admin_model->delete_seller($id);
        redirect('admin/seller_register');
    }

    public function edit_seller() {
        $id = $_REQUEST['id'];
        $data['seller'] = $this->admin_model->get_seller_id($id);
        $data['content'] = 'edit_seller';
        $data['title'] = 'edit_seller';
//        $data['get_seller'] = $this->admin_model->get_seller();

        $this->load->view('template/admin_template', $data);
    }

    public function update_seller() {

        $this->admin_model->update_seller($id);
        redirect('admin/view_seller');
    }

}
