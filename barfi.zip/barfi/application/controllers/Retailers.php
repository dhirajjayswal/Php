<?php 

class Retailers extends CI_Controller {

  public function __construct() {

    parent::__construct();

    $this->load->database();
    $this->load->helper('url');
    $this->load->library('Grocery_CRUD');
    $this->load->library('Grocery_CRUD');
    $this->load->helper('security');
    //$this->load->library('image_CRUD');
    $this->load->library('session');
  }

  public function index()

  {
    // print_r($this->session);exit();
    // echo($this->session->userdata["user_name"]);exit();
    // echo "string".$this->session->userdata["user_name"];exit();
    $crud = new grocery_CRUD();
    $crud->set_theme('datatables');
    $crud->set_subject("Retailers");
    $crud->set_table('barfi_retailers');   

    /* SETTING FIELDS */

    /* Setting dropdown fields */
    $crud->field_type('status','dropdown',array('active' => 'active', 'inactive' => 'inactive'));
    /*$crud->field_type('type','dropdown',array('Ink Pen' => 'Ink Pen', 'Ball Pen' => 'Ball Pen'));
    $crud->field_type('status','dropdown',array('active' => 'active', 'inactive' => 'inactive'));
    $crud->field_type('shippable','dropdown',array('yes' => 'yes', 'no' => 'no'));*/

    /* Setting Multiselect fields */
    /*$crud->field_type('color','multiselect',array('red' => 'red', 'green' => 'green', 'blue' => 'blue'));
    $crud->field_type('packages','multiselect',$pkgs);*/
    // $crud->field_type('packages','multiselect',array('1' => 'Pack of 5', '2' => 'Pack of 10'));
    /*$crud->field_type('uploader_id', 'hidden', $this->session->userdata["user_name"]);
    $crud->field_type('upload_date', 'hidden', date("d-m-Y"));*/
    // $crud->field_type('date', 'hidden', date("d-m-Y"));

    // $crud->field_type('timestamp', 'hidden', date("d-m-Y"));
    $crud->display_as('c_name','Company Name')
         ->display_as('contactp_name','Contact Person')
         ->display_as('contactp_number','Contact Person No.');
    $crud->columns('id','c_name','contactp_name','contactp_number');
    // $crud->fields('id','c_name','contactp_name','contactp_number','email','address','pincode');
    // $crud->fields('c_name','contactp_name','contactp_number');

    /* Unsetting Delete */
    if (isset($this->session->userdata["user_role"]) && ($this->session->userdata["user_role"] == 'sa' || $this->session->userdata["user_role"] == 'st' || $this->session->userdata["user_role"] == 'rt')) {
      $crud->unset_delete();
    }



    /* Insert new login with otp in tbl_admin_master start */
    //echo "<pre>";
    //$a = $this->session->userdata;
    $otp = rand(1000,9999);
    // $post_array = array("user_name"=>"abc","password"=>$otp,"role"=>"rt","status"=>"inactive","otp"=>1,"added_by"=>$this->session->userdata["user_name"],"12-5-2018");
    $crud->callback_after_insert(array($this, 'add_retailer_login'));  
    // $this->db->last_query();exit();
    /* Insert new login with otp in tbl_admin_master end */


    $output = $crud->render();
    $a = "";
    if (isset($this->session->userdata["user_name"])) {
        $a =  $this->session->userdata["user_name"];
    }else {
        $a = "User";
    }
    $output1 = array('title' => 'Barfi | Retailers', 'header' => 'Retailers', 'username' => $a);
    $output = array_merge((array) $output, $output1);

    // $this->load->view('admin_template.php', $output);
    $this->_example_output($output);
  }    

  function _example_output($output = null)
  {
    $this->load->view('admin_template.php',$output); 
  }

  function add_retailer_login($post_array="",$primary_key="")
  { 
    // echo "<pre>";
  //   print_r($post_array);
  //   print_r($primary_key);
  //   exit();
    $otp = rand(1000,9999);
    $date = date("d-m-Y");
    $fields = array(
    "user_id" => $primary_key,
    "user_name" => $post_array["c_name"],
    "password" => $otp,
    "role" => "rt",
    "status" => "inactive",
    "otp" => 1,
    "added_by" => $this->session->userdata["user_name"],
    "date" => $date
    );

    // $this->load->model("home_model");
    // $this->home_model->
     
    $this->db->insert('tbl_admin_master',$fields) or die("error is ".$this->db->mysqli_error());
     
    return true;
  }
}