<?php 

class Orders extends CI_Controller {

  public function __construct() {

    parent::__construct();

    $this->load->database();
    $this->load->helper('url');
    $this->load->library('Grocery_CRUD');
    $this->load->library('session');
  }

  public function load($op="",$id="")
  {
    // echo "<pre>";exit();
  //   print_r($this->session->userdata);
  //   echo "string".$this->session->user_name;exit();
    $crud = new grocery_CRUD();
    $crud->set_theme('datatables');
    $crud->set_subject("Orders");
    $crud->columns('id','product_id','product_name');
    $crud->set_table("barfi_orders");
    //$crud->where('added_by',$this->session->userdata["user_name"]);
// 
    /* SETTING FIELDS */
    // $crud->set_relation('product_id','tbl_product','id');
    // $crud->set_relation('product_name','tbl_product','name');
    // $crud->set_relation('product_cat','barfi_product_cat','name');
    // $crud->set_relation('product_subcat','barfi_product_subcat','name');
    // $crud->set_relation('product_subcat','tbl_product','sub_category');
    // $crud->set_relation('product_color','barfi_product_color','name');
    
    // $crud->set_relation('retailer_id','barfi_retailers','id');
    // $crud->set_relation('retailer_name','barfi_retailers','c_name');
    

    /* Setting dropdown fields */
    // $crud->field_type('type','dropdown',array('Ink Pen' => 'Ink Pen', 'Ball Pen' => 'Ball Pen'));
    // $crud->field_type('status','dropdown',array('active' => 'active', 'inactive' => 'inactive'));
    // $crud->field_type('shippable','dropdown',array('yes' => 'yes', 'no' => 'no'));

    /* Setting Multiselect fields */
    // $crud->field_type('packages','multiselect',$my_packages);
    // $crud->field_type('uploader_id', 'hidden', $this->session->user_name);
    // $crud->field_type('upload_date', 'hidden', date("d-m-Y"));
    // $crud->field_type('time', 'hidden', date("d-m-Y"));

    /* Adding Hidden Data to Fields */
    // $crud->field_type('added_by', 'hidden', $this->session->userdata["user_name"]);
    // $crud->field_type('date', 'hidden', date("d-m-Y"));
    // $crud->field_type('timestamp', 'hidden', date("Y-m-d G:i:s"));

    // $crud->columns('id');
    // $crud->field_type('product_name','readonly','test');
    $this->load->model("home_model");
    $p_info = $this->home_model->get_product_info($id);
    // echo "<pre>";
 // print_r($p_info);exit();

    if(!empty($p_info)){

    $_SESSION["p_info"] = $p_info[0];
    // print_r($_SESSION["p_info"]);exit();

    $crud->field_type('timestamp', 'hidden', $_SESSION["p_info"]["timestamp"]);
    $crud->field_type('added_by', 'hidden');
    $crud->field_type('product_id', 'hidden');
    // print_r($_SESSION["p_info"]);exit();
    $crud->callback_add_field('product_name', function () {
      return '<input type="text" maxlength="50" value="'.$_SESSION["p_info"]["name"].'" name="product_name" readonly>';
    });
    $crud->callback_add_field('product_code', function () {
      return '<input type="text" maxlength="50" value="'.$_SESSION["p_info"]["product_code"].'" name="product_code" readonly>';
    });
    $crud->callback_add_field('product_cat', function () {
      return '<input type="text" maxlength="50" value="'.$_SESSION["p_info"]["category"].'" name="product_cat" readonly>';
    });
    $crud->callback_add_field('product_subcat', function () {
      return '<input type="text" maxlength="50" value="'.$_SESSION["p_info"]["sub_category"].'" name="product_subcat" readonly>';
    });
    $crud->callback_add_field('product_brand', function () {
      return '<input type="text" maxlength="50" value="'.$_SESSION["p_info"]["brand_name"].'" name="product_brand" readonly>';
    });
    $crud->callback_add_field('product_avl_quantity', function () {
      return '<input type="text" id="avl_qty" maxlength="50" value="'.$_SESSION["p_info"]["quantity"].'" name="product_avl_quantity" readonly>';
    });
    $crud->callback_add_field('product_mrp', function () {
      return '<input type="text" id="prod_mrp" maxlength="50" value="'.$_SESSION["p_info"]["mrp"].'" name="product_mrp" readonly>';
    });
    $crud->callback_add_field('prod_desc', function () {
      return '<input type="text" maxlength="150" value="'.$_SESSION["p_info"]["description"].'" name="prod_desc" readonly>';
    });
    $crud->callback_add_field('order_status', function () {
      return '<input type="text" maxlength="50" value="'.$_SESSION["p_info"]["status"].'" name="order_status" readonly>';
    });
    $crud->callback_add_field('timestamp', function () {
      return '<input type="hidden" maxlength="50" value="'.$_SESSION["p_info"]["timestamp"].'" name="timestamp" readonly>';
    });
    $crud->callback_add_field('gst', function () {
      return '<input type="text" maxlength="50" id="p_gst" value="'.$_SESSION["p_info"]["gst"].'" name="gst" readonly>';
    });
    $crud->callback_add_field('discount', function () {
      return '<input type="text" id="p_discount" maxlength="50" value="'.$_SESSION["p_info"]["discount"].'" name="discount" readonly>';
    });
    $crud->callback_add_field('product_color', function () {
      return '<input type="text" maxlength="50" value="'.$_SESSION["p_info"]["colors"].'" name="colors ">';
     });
    $crud->callback_add_field('total', function () {
      return '<input type="text" maxlength="50" id="prod_total" value=" " name="total" readonly>';
     });
    }


    // $crud->field_type('product_color','set',array($_SESSION["p_info"]['0'],$_SESSION["p_info"]['1'],$_SESSION["p_info"]['2'],$_SESSION["p_info"]['3']));


    $output = $crud->render();
    $output1 = array('title' => 'Barfi | Orders', 'header' => 'Orders');
    $output = array_merge((array) $output, $output1);

    $this->load->view('admin_template.php', $output);
   }
   function output_to_view($view = null,$data = null)
      {
        $this->load->view($view,$data); 
      }


  public function getOrder()
  {
    // if (isset($this->session->retailer_name)) {
    //   echo "Retailer is ".$this->session->retailer_name;
    // } else {
    //   echo "Sorry You are not logged in Please log in!!!<PRE>";
    //   print_r($this->input->post());
      $category = "";
      if (isset($_POST["p_cat"]) && !empty($_POST["p_cat"])) {
        $category = array('category' => array($_POST["p_cat"]));
        $_REQUEST = $category;
        //print_r($_REQUEST);
        //echo "flj";
      }
      $a = "";
      if (isset($this->session->userdata["user_name"])) {
          $a =  $this->session->userdata["user_name"];
      }else {
          $a = "";
      }
      $this->load->model("home_model");
      $this->load->library('pagination');
      $all_products["status"] = $this->home_model->add_order()?"Form Submitted Successfully!!!":"Sorry, Unable to Submit the data!!!";
      $p_count = $this->home_model->get_products_count();
      $config['base_url'] = base_url()."home/products";
      $config['total_rows'] = $p_count;
      $config['per_page'] = 6;
      $config["cur_tag_open"] = "<a style='text-decoration:none;font-weight:800;font-size:20px;'>";
      $config["cur_tag_close"] = "</a>";
      $config["uri_segment"] = 3;
      $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
      $where = $_REQUEST;
      $all_products["all_products"] = $this->home_model->get_products($config['per_page'],$page,$where);
      $all_products["product_cat"] = $this->home_model->get_product_cat();
      $all_products["product_colors"] = $this->home_model->get_product_colors();
      $all_products["product_brand"] = $this->home_model->get_product_brand();
      $all_products["nav_data"] = $where;
                

      $this->pagination->initialize($config);

      $all_products["links"] = $this->pagination->create_links();
      /* Pagination End */

      $output = array('title' => 'Barfi | Products', 'header' => 'Products', 'username' => $a ,'category'=>$category);
      $output = array_merge((array) $output, $all_products);
      
      $this->output_to_view('home/products.php',$output);
    }
  }
