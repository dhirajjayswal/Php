<?php 

class Enquiries extends CI_Controller {

  public function __construct() {

    parent::__construct();

    $this->load->database();
    $this->load->helper('url');
    $this->load->library('Grocery_CRUD');
    $this->load->library('session');
  }

  public function load()
  {
    // echo "<pre>";
  //   print_r($this->session->userdata);
  //   echo "string".$this->session->user_name;exit();
    $crud = new grocery_CRUD();
    $crud->set_theme('datatables');
    $crud->set_subject("Enquiries");
    $crud->columns('product_id','product_name','product_avl_quantity');
    $crud->set_table("barfi_enquire");
    $crud->unset_add();
    //$crud->where('added_by',$this->session->userdata["user_name"]);
// 
    /* SETTING FIELDS */
    // $crud->set_relation('product_id','tbl_product','id');
    // $crud->set_relation('product_name','tbl_product','name');
    // $crud->set_relation('product_cat','barfi_product_cat','name');
    // $crud->set_relation('product_subcat','barfi_product_subcat','name');
    // $crud->set_relation('product_subcat','tbl_product','sub_category');
    // $crud->set_relation('product_color','barfi_product_color','name');
    
    // $crud->set_relation('retailer_id','barfi_retailers','id');
    // $crud->set_relation('retailer_name','barfi_retailers','c_name');
    

    /* Setting dropdown fields */
    // $crud->field_type('type','dropdown',array('Ink Pen' => 'Ink Pen', 'Ball Pen' => 'Ball Pen'));
    // $crud->field_type('status','dropdown',array('active' => 'active', 'inactive' => 'inactive'));
    // $crud->field_type('shippable','dropdown',array('yes' => 'yes', 'no' => 'no'));

    /* Setting Multiselect fields */
    // $crud->field_type('packages','multiselect',$my_packages);
    // $crud->field_type('uploader_id', 'hidden', $this->session->user_name);
    // $crud->field_type('upload_date', 'hidden', date("d-m-Y"));
    // $crud->field_type('time', 'hidden', date("d-m-Y"));

    /* Adding Hidden Data to Fields */
    // $crud->field_type('added_by', 'hidden', $this->session->userdata["user_name"]);
    // $crud->field_type('date', 'hidden', date("d-m-Y"));
    // $crud->field_type('timestamp', 'hidden', date("Y-m-d G:i:s"));

    // $crud->columns('id');
    $output = $crud->render();
    $output1 = array('title' => 'Barfi | Enquiries', 'header' => 'Enquiries');
    $output = array_merge((array) $output, $output1);

    $this->load->view('admin_template.php', $output);
  }
  function output_to_view($view = null,$data = null)
      {
        $this->load->view($view,$data); 
      }

  
  }
