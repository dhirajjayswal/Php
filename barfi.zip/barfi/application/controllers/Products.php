<?php 

class Products extends CI_Controller {

  public function __construct() {

    parent::__construct();

    $this->load->database();
    $this->load->helper('url');
    $this->load->library('Grocery_CRUD');
    $this->load->library('image_CRUD');
    $this->load->library('session');
    $this->load->library('pagination');
    
  }

  public function multiselect_ready($var,$field)
  {
    $data = array();
   foreach ($var as $key => $value) {
     $temp = $value["$field"];
      $data[$temp] = $temp; 
    }
    //print_r $var;
    return $data;
  }

  public function load()

  {
    //print_r($this->session);exit();
    if (!isset($this->session->user_name)) {
      echo "You are logged out !!! Please log in";
      redirect(base_url("index.php/admin"));
    }
    // echo($this->session->userdata["user_name"]);exit();
    // echo "string".$this->session->userdata["user_name"];exit();
    $crud = new grocery_CRUD();
    $crud->set_theme('datatables');
    $crud->set_subject("Product");
    $crud->set_table('tbl_product');

    /* Get Packages Entered By the User */
    $this->load->model("admin_model");
    $my_packages = $this->admin_model->get_packages($this->session->userdata["user_name"]);
    // echo "<pre>";
    // print_r($my_packages);exit();
    $pkgs = "";
    /*foreach ($my_packages as $key => $value) {
      $temp = $value["name"];
      $pkgs[$temp] = $temp; 
    }*/
    $pkgs = $this->multiselect_ready($my_packages,"name");

     //print_r($pkgs);
     //print_r($my_packages);exit();
    // print_r($pkgs);exit();

    /* SETTING FIELDS */

    /* Setting dropdown fields */
    $crud->field_type('type','dropdown',array('Ink Pen' => 'Ink Pen', 'Ball Pen' => 'Ball Pen', 'Gel Pen' => 'Gel Pen'));
    $crud->field_type('status','dropdown',array('active' => 'active', 'inactive' => 'inactive'));
    $crud->field_type('shippable','dropdown',array('yes' => 'yes', 'no' => 'no'));
    $crud->field_type('upcoming','dropdown',array('yes' => 'yes', 'no' => 'no'));
    $crud->field_type('main_categories','dropdown',array('domestic' => 'domestic', 'international' => 'international'));
    $crud->field_type('discount','dropdown',array('2.5' => '2.5%','5' => '5%', '10' => '10%'));
    $crud->field_type('gst','dropdown',array('2.5' => '2.5%','5' => '5%', '10' => '10%'));

    // $crud->set_relation('category','barfi_product_cat','name');
    $this->load->model("home_model");

    $p_cat = $this->home_model->get_product_cat();
    $p_cat = $this->multiselect_ready($p_cat,"name");
    $crud->field_type('category','dropdown',$p_cat);

    $p_subcat = $this->home_model->get_product_subcat();
    $p_subcat = $this->multiselect_ready($p_subcat,"name");
    $crud->field_type('sub_category','dropdown',$p_subcat);

    // $crud->set_relation('sub_category','barfi_product_subcat','name');

    /*Dependent lists start */
    /*$this->load->library('gc_dependent_select'); 
    $fields = array(
    'category' => array(// first dropdown name
    'table_name' => 'barfi_product_cat', // table of country
    'title' => 'name', // country title
    'relate' => null // the first dropdown hasn't a relation
    ),
    'sub_category' => array(// second dropdown name
    'table_name' => 'barfi_product_subcat', // table of state
    'title' => 'name', // state title
    'id_field' => 'category', // table of state: primary 

    
    'relate' => 'category', // table of state:
    'data-placeholder' => 'sub_category' //dropdown's data-placeholder:
    )
    );
    $config = array(
    'main_table' => 'tbl_product',
    'main_table_primary' => 'id',
    'url'=>base_url().__CLASS__.'/'.__METHOD__.'/' 
    );
    $categories = new gc_dependent_select($crud, $fields, $config);
    $js = $categories->get_js();*/
    /*Dependent lists end */

    /* Setting Multiselect fields */
    $colors = $this->admin_model->get_colors();
    // $temp_color = array();
    // foreach ($colors as $key => $value) {
    //   $temp_color[$value["name"]] = $value["name"];
    // }
    $temp_color = $this->multiselect_ready($colors,"name");
    $crud->field_type('colors','multiselect',$temp_color);

    // print_r($temp_color);exit();
    // $crud->field_type('colors','multiselect',array('red' => 'red', 'green' => 'green', 'blue' => 'blue', 'black' => 'black'));
    $crud->field_type('packages','multiselect',$pkgs);
    // $crud->field_type('packages','multiselect',array('1' => 'Pack of 5', '2' => 'Pack of 10'));
    $crud->field_type('uploader_id', 'hidden', $this->session->userdata["user_name"]);
    $crud->field_type('upload_date', 'hidden', date("d-m-Y"));
    $crud->set_field_upload('image','assets/uploads');
    // $crud->field_type('date', 'hidden', date("d-m-Y"));
    date_default_timezone_set("Asia/Kolkata");
    // echo "time".date_default_timezone_get();
    $crud->field_type('timestamp', 'hidden', date("d-m-Y h:i:sa"));
    $crud->columns('product_code','name','category','image','description');

    /* Setting Image Gallery */
    $crud->add_action('Gallery', '', 'Products/gallery', 'ui-icon-plus');
    $crud->add_action('Order', '', 'Orders/load/add', 'ui-icon-plus');

    if (isset($this->session->userdata["user_role"]) && ($this->session->userdata["user_role"] == 'sa' || $this->session->userdata["user_role"] == 'st' || $this->session->userdata["user_role"] == 'rt')) {
      $crud->unset_delete();
    }

    $output = $crud->render();
    // $output->output.= $js;
    $a = "";
    if (isset($this->session->userdata["user_name"])) {
        $a =  $this->session->userdata["user_name"];
    }else {
        $a = "";
    }
    $output1 = array('title' => 'Barfi | Products', 'header' => 'Products', 'username' => $a);
    $output = array_merge((array) $output, $output1);

    // $this->load->view('admin_template.php', $output);
    $this->_example_output($output);
  }

  public function gallery($product_id)
  {
       
    $image_crud = new image_CRUD();
  
    $image_crud->set_primary_key_field('id');
    $image_crud->set_url_field('url');
    $image_crud->set_title_field('title');
    $image_crud->set_table('barfi_product_imgs')
    ->set_relation_field('product_id')
    ->set_ordering_field('product_id')  //Setting where clause
    ->set_image_path('assets/uploads');
      
    $output = $image_crud->render();
    $a = "";
    if (isset($this->session->userdata["user_name"])) {
        $a =  $this->session->userdata["user_name"];
    }else {
        $a = "";
        echo "Please Log in to continue!!!";
        redirect(base_url("admin"));
        exit();
    }
    $output1 = array('title' => 'Barfi | Products', 'header' => 'Gallery', 'username' => $a);
    $output = array_merge((array) $output, $output1);
    
    $this->_example_output($output);
  }

  /* Product Category function Start */
  public function category()
  {
    $crud = new grocery_CRUD();
    $crud->set_theme('datatables');
    $crud->set_subject("Product Category");
    $crud->set_table('barfi_product_cat');
    $crud->columns('name','desc','image');

    /* Adding Required Fields */
    $crud->required_fields('name');

    /* Adding Hidden Data to Fields */
    $crud->field_type('added_by', 'hidden', $this->session->userdata["user_name"]);    
    date_default_timezone_set("Asia/Kolkata");/* Setting Default timezone for adding date */
    $crud->field_type('date', 'hidden', date("d-m-Y"));
    $crud->set_field_upload('image','assets/uploads');

    if (isset($this->session->userdata["user_role"]) && ($this->session->userdata["user_role"] == 'sa' || $this->session->userdata["user_role"] == 'st' || $this->session->userdata["user_role"] == 'rt')) {
      $crud->unset_delete();
    }

    $output = $crud->render();
    /* Username Start */
    $a = "";
    if (isset($this->session->userdata["user_name"])) {
        $a =  $this->session->userdata["user_name"];
    }else {
        $a = "";
        echo "Please Log in to continue!!!";
        redirect(base_url("index.php/admin"));
        exit();
    }

    /* Username End */
    $output1 = array('title' => 'Barfi | Product Category', 'header' => 'Product Category', 'username' => $a);
    $output = array_merge((array) $output, $output1);
    
    $this->_example_output($output);
  }
  /* Product Category function End */

  /* Product Sub-Category function Start */
  public function subcategory()
  {
    $crud = new grocery_CRUD();
    $crud->set_theme('datatables');
    $crud->set_subject("Product Sub-Category");
    $crud->set_table('barfi_product_subcat');
    $crud->columns('name','category','desc');
    $crud->set_rules('name','Name field','required');

    /* Adding Required Fields */
    
    $crud->set_relation('category','barfi_product_cat','name');
    $crud->required_fields('name','category');


    /* Adding Hidden Data to Fields */
    $crud->field_type('added_by', 'hidden', $this->session->userdata["user_name"]);    
    date_default_timezone_set("Asia/Kolkata");/* Setting Default timezone for adding date */
    $crud->field_type('date', 'hidden', date("d-m-Y"));

    if (isset($this->session->userdata["user_role"]) && ($this->session->userdata["user_role"] == 'sa' || $this->session->userdata["user_role"] == 'st' || $this->session->userdata["user_role"] == 'rt')) {
      $crud->unset_delete();
    }

    $output = $crud->render();
    /* Username Start */
    $a = "";
    if (isset($this->session->userdata["user_name"])) {
        $a =  $this->session->userdata["user_name"];
    }else {
        $a = "";
        echo "Please Log in to continue!!!";
        redirect(base_url("index.php/admin"));
        exit();
    }

    /* Username End */
    $output1 = array('title' => 'Barfi | Product Sub-Category', 'header' => 'Product Sub-Category', 'username' => $a);
    $output = array_merge((array) $output, $output1);
    
    $this->_example_output($output);
  }
  /* Product Sub-Category function End */

  /* Product Brand function Start */
  public function brand()
  {
    $crud = new grocery_CRUD();
    $crud->set_theme('datatables');
    $crud->set_subject("Product Brand");
    $crud->set_table('barfi_product_brand');
    $crud->columns('name','desc');
    /* Adding Required Fields */
    $crud->required_fields('name');

    /* Adding Hidden Data to Fields */
    $crud->field_type('added_by', 'hidden', $this->session->userdata["user_name"]);    
    date_default_timezone_set("Asia/Kolkata");/* Setting Default timezone for adding date */
    $crud->field_type('date', 'hidden', date("d-m-Y"));

    if (isset($this->session->userdata["user_role"]) && ($this->session->userdata["user_role"] == 'sa' || $this->session->userdata["user_role"] == 'st' || $this->session->userdata["user_role"] == 'rt')) {
      $crud->unset_delete();
    }

    $output = $crud->render();
    /* Username Start */
    $a = "";
    if (isset($this->session->userdata["user_name"])) {
        $a =  $this->session->userdata["user_name"];
    }else {
        $a = "";
        echo "Please Log in to continue!!!";
        redirect(base_url("index.php/admin"));

        exit();
    }
    /* Username End */
    $output1 = array('title' => 'Barfi | Product Brand', 'header' => 'Product Brand', 'username' => $a);
    $output = array_merge((array) $output, $output1);
    
    $this->_example_output($output);
  }
  /* Product Brand function End */

  /* Product Colors function Start */
  public function colors()
  {
    $crud = new grocery_CRUD();
    $crud->set_theme('datatables');
    $crud->set_subject("Product Colors");
    $crud->set_table('barfi_product_color');
    $crud->columns('name','desc');
    /* Adding Required Fields */
    $crud->required_fields('name');

    /* Adding Hidden Data to Fields */
    $crud->field_type('added_by', 'hidden', $this->session->userdata["user_name"]);    
    date_default_timezone_set("Asia/Kolkata");/* Setting Default timezone for adding date */
    $crud->field_type('date', 'hidden', date("d-m-Y"));

    if (isset($this->session->userdata["user_role"]) && ($this->session->userdata["user_role"] == 'sa' || $this->session->userdata["user_role"] == 'st' || $this->session->userdata["user_role"] == 'rt')) {
      $crud->unset_delete();
    }

    $output = $crud->render();
    /* Username Start */
    $a = "";
    if (isset($this->session->userdata["user_name"])) {
        $a =  $this->session->userdata["user_name"];
    }else {
        $a = "";
        echo "Please Log in to continue!!!";
        redirect(base_url("index.php/admin"));

        exit();
    }
    /* Username End */
    $output1 = array('title' => 'Barfi | Product Colors', 'header' => 'Product Colors', 'username' => $a);
    $output = array_merge((array) $output, $output1);
    
    $this->_example_output($output);
  }
  /* Product Brand function End */

 

  function _example_output($output = null)
  {
    $this->load->view('admin_template.php',$output); 
  }

  
}