<?php 

class Subadmin extends CI_Controller {

    public function __construct() {

        parent::__construct();

        $this->load->database();
        // $this->load->helper('form');
        $this->load->helper('url');
        // $this->load->library('form_validation');
        $this->load->library('Grocery_CRUD');
        // $this->load->model('admin_model');
        // $this->load->library('session');
    }

    public function index() {        
        // echo "i am in sub admin";
                
       
        try{
            $this->load();
            /*$crud = new grocery_CRUD();

            $crud->set_theme('datatables');
            $crud->set_table('tbl_user');
            // $crud->set_theme('datatables');
            // $crud->set_table('offices');
            $crud->set_subject('Office');
            $output = $crud->render();
            //$data['content'] = "subadmin";
            //$output['t'] = "SubAdmin";
            //$data['table'] = $output;
            $this->load->view('admin/subadmin.php',$output);*/
            // $crud->where('role','1');

            // $crud->required_fields('firstname','lastname','username');
            // $crud->columns('id','firstname','lastname','username','role');

            // $data['table'] = $crud->render();
            // $d = $crud->render();
            // echo ($d);exit();
            
            // $data['content'] = "subadmin";            

            // $this->load->view('template/admin_template', $data);

        }catch(Exception $e){
            show_error($e->getMessage().' --- '.$e->getTraceAsString());
        }
    }

    public function load()
    {
        try{
            $crud = new grocery_CRUD();

            $crud->set_theme('datatables');
            $crud->set_table('tbl_user');
            $crud->where('role',2);
            // $crud->set_theme('datatables');
            // $crud->set_table('offices');
            // $output = $crud->render();
            /*echo "<pre>";
            print_r($output);
            echo "</pre>";
            die();*/
            // $data['content'] = "subadmin";
            // $data['table'] = $output;
            // $this->load->view('admin/subadmin.php',(array)$output);
            $crud->columns('id','firstname','lastname','username');
            $output = $crud->render();
            $output1 = array('title' => 'Barfi | Sub-Admin', 'header' => 'Sub-Admin');
            $output = array_merge((array) $output, $output1);

            $this->load->view('admin_template.php', $output);
        }catch(Exception $e){
            show_error($e->getMessage().' --- '.$e->getTraceAsString());
        }
    }

    

    

}