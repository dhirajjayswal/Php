<?php 

class Salesteam extends CI_Controller {

  public function __construct() {

    parent::__construct();

    $this->load->database();
    $this->load->helper('url');
    $this->load->library('Grocery_CRUD');
    $this->load->library('session');
  }

  public function index()
  {
    if (isset($this->session->userdata["user_name"]) && $this->session->userdata["user_name"]!="") {
      
    $crud = new grocery_CRUD();
    $crud->set_theme('datatables');
    $crud->set_subject("Sales Team");
    $crud->where('role','st');
    $crud->set_table('tbl_admin_master');
    $crud->required_fields('user_name','password','status');
    $crud->columns('user_name','password','status');

    /* SETTING FIELDS */
 
    $crud->field_type('role', 'hidden', 'st');
    $crud->field_type('user_id', 'hidden', '');
    $crud->field_type('otp', 'hidden', '');
    
    $crud->field_type('status','dropdown',array('active' => 'active', 'inactive' => 'inactive'));

    /* Adding Hidden Data to Fields */
    // print_r($this->session);
    $crud->field_type('added_by', 'hidden', $this->session->userdata["user_name"]);    
    date_default_timezone_set("Asia/Kolkata");/* Setting Default timezone for adding date */
    $crud->field_type('date', 'hidden', date("d-m-Y"));

    if (isset($this->session->userdata["user_role"]) && ($this->session->userdata["user_role"] == 'sa' || $this->session->userdata["user_role"] == 'st' || $this->session->userdata["user_role"] == 'rt')) {
      $crud->unset_delete();
    }

    if (isset($this->session->userdata["user_role"]) && ($this->session->userdata["user_role"] == 'st' || $this->session->userdata["user_role"] == 'rt')) {
      $crud->unset_add();
    }

    $output = $crud->render();
    $output1 = array('title' => 'Barfi | Sales Team', 'header' => 'Sales Team');
    $output = array_merge((array) $output, $output1);

    $this->load->view('admin_template.php', $output);
    } else {
      echo "Sorry, You have been logged out !!! Please login again";
      redirect(base_url("admin"));
    }
  }
}