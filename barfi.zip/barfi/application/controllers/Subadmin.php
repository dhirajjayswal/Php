<?php 

class Subadmin extends CI_Controller {

  public function __construct() {

    parent::__construct();

    $this->load->database();
    $this->load->helper('url');
    $this->load->library('Grocery_CRUD');
    $this->load->library('session');
  }

  public function index()
  {
  
    $crud = new grocery_CRUD();
    $crud->set_theme('datatables');
    $crud->set_subject("Sub Admin");
    $crud->where('role','sa');
    $crud->set_table('tbl_admin_master');
    $crud->required_fields('user_name','password','status');
    $crud->columns('user_name','password','status');

    /* SETTING FIELDS */
    $otp = 
    $crud->field_type('role', 'hidden', 'sa');
    $crud->field_type('otp', 'hidden', '');
    $crud->field_type('user_id', 'hidden', '');
    $crud->field_type('status','dropdown',array('active' => 'active', 'inactive' => 'inactive'));

    /* Adding Hidden Data to Fields */

    $crud->field_type('added_by', 'hidden', $this->session->userdata["user_name"]);    
    date_default_timezone_set("Asia/Kolkata");/* Setting Default timezone for adding date */
    $crud->field_type('date', 'hidden', date("d-m-Y"));

    /* Displaying Data */
    $output = $crud->render();
    $output1 = array('title' => 'Barfi | Sub Admin', 'header' => 'Sub Admin');
    $output = array_merge((array) $output, $output1);

    $this->load->view('admin_template.php', $output);
  }
}