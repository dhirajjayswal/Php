<?php

if (!defined('BASEPATH')){
    exit('No direct script access allowed');
}

class Home extends CI_Controller {

    public function __construct() {

        parent::__construct();

        $this->load->database();
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('pagination');
        $this->load->library('Grocery_CRUD');
        // echo "<pre>";
        // print_r($this->session);
        //$this->load->model("home_model");
    }

// Loads contact us form to admin panel /////
  public function load()
      {
        $crud = new grocery_CRUD();
        $crud->set_theme('datatables');
        $crud->set_subject("Contact Us");
        $crud->columns('name','email','phone','subject','message');
        $crud->set_table("barfi_contact");
        $crud->unset_add();
        $crud->unset_edit();

         $output = $crud->render();
        $output1 = array('title' => 'Barfi | Contact', 'header' => 'Contact');
        $output = array_merge((array) $output, $output1);

        $this->load->view('admin_template.php', $output);
      
      function output_to_view($view = null,$data = null)
          {
            $this->load->view($view,$data); 
          }
  }
    



    public function get_details(){



      $this->load->model('home_model');
      // $data = $this->home_model->get_details();
      $data["product_cat"] = $this->home_model->get_product_cat();
      //print_r($data["product_cat"]);
       //$data = $this->home_model->get_product_cat();
      $this->load->view('home/home.php', $data);
      $this->load->view('home/gallery.php', $data);



    }
    // public function photos()
    //   {
    //     $this->load->model("home_model");
    //     $output["all_prod"] = $this->home_model->get_all_products();
    //     $output["product_cat"] = $this->home_model->get_product_cat();

    //     if (isset($_POST["p_id"]) && !empty($_POST["p_id"])) {
    //       $output["product_imgs"] = $this->home_model->get_gallery_images();        
    //     }
      
    //   // $this->output_to_view('home/gallery.php',$output);
         
    //     $this->load->view("home/gallery.php",$output);
    //   }

    public function products()
    { 



     // print_r($_REQUEST);exit();
      $category = "";
      if (isset($_POST["p_cat"]) && !empty($_POST["p_cat"])) {
        $category = array('category' => array($_POST["p_cat"]));
        $_REQUEST = $category;
        //print_r($_REQUEST);
        //echo "flj";
      }

       
      /*print_r($_REQUEST);

      if (!isset($this->session->user_name)) {
        echo "You are logged out !!! Please log in";
        redirect(base_url("index.php/admin"));
      }*/

      $a = "";
      if (isset($this->session->userdata["user_name"])) {
          $a =  $this->session->userdata["user_name"];
      }else {
          $a = "";
      }

      
      
      /* Pagination Start */
      // $this->load->library('pagination');
      $this->load->model("home_model");

      

      $p_count = $this->home_model->get_products_count();
      $config['base_url'] = base_url()."home/products";
      $config['total_rows'] = $p_count;
      $config['per_page'] = 6;
      $config["cur_tag_open"] = "<a style='text-decoration:none;font-weight:800;font-size:20px;'>";
      $config["cur_tag_close"] = "</a>";
      $config['next_link'] = 'Next';
      $config['prev_link'] = 'Prev';
      $config["uri_segment"] = 3;
      $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
      $where = $_REQUEST;
      $all_products["all_products"] = $this->home_model->get_products($config['per_page'],$page,$where);
      $all_products["product_cat"] = $this->home_model->get_product_cat();
      $all_products["product_subcat"] = $this->home_model->get_product_subcat();
      $all_products["product_colors"] = $this->home_model->get_product_colors();
      $all_products["product_brand"] = $this->home_model->get_product_brand();
      $all_products["nav_data"] = $where;
                

      $this->pagination->initialize($config);

      $all_products["links"] = $this->pagination->create_links();
      /* Pagination End */

      $output = array('title' => 'Barfi | Products', 'header' => 'Products', 'username' => $a ,'category'=>$category);
      $output = array_merge((array) $output, $all_products);
      
      $this->output_to_view('home/products.php', $output);

      // $this->output_to_view('home/gallery.php',$output);
    }

    public function index() {
      // echo "<pre>";
      // print_r($this->session);

       $this->load->model("home_model");
        //$this->home_model->get_details();
        //$cat['fetch_data']= $this->home_model->fetch_data();
        //$this->load->view->("home",$cat);
       $output["product_cat"] = $this->home_model->get_product_cat();
        // $output["products"] = $this->home_model->get_6_products();
        $this->output_to_view('home/home.php',$output);
    }
    
    public function testview() {
        $this->output_to_view('testview.php',"");
    }

    public function about_us() {
        $this->output_to_view('home/about_us.php',"");
    }

    public function gallery(){
      $this->load->model("home_model");
      $output["all_prod"] = $this->home_model->get_all_products();
      $output["product_cat"] = $this->home_model->get_product_cat();
      if (isset($_POST["p_id"]) && !empty($_POST["p_id"])) {
      $output["product_imgs"] = $this->home_model->get_gallery_images($_POST["p_id"]);        
      }
      $this->output_to_view('home/gallery.php',$output);
    }

    public function video_gallery(){
      $this->load->model("home_model");
     // $output["all_prod"] = $this->home_model->get_all_products();
      $this->output_to_view('home/video_gallery.php'," ");
    }

     public function contact(){

      $this->load->model("home_model");
      $data["status"] = $this->home_model->contact();
      $this->output_to_view('home/contact.php',$data);
    }

    public function retailer_reset_pwd($uid="") 
    {
      $this->load->model("home_model");

      if (isset($_POST["new_pass"]) && !empty($_POST["new_pass"]) ) {
        $this->home_model->retailer_reset_pwd($_POST["user_id"],$_POST["new_pass"]);
      }else{
        $output["uid"] = $uid;
        $this->output_to_view('home/retailer_reset_pwd',$output);        
      }
    }

    public function retailer_login(){
      /*echo "<pre>";
        print_r($this->session);*/
        $this->load->model("home_model");
         if (isset($_POST["username"])) {
        $data = $this->home_model->retailer_login();
        // echo "sldjflsj";exit();
        // print_r($data);
        if ($data) {
            $this->session->set_flashdata('login_msg', 'Login Successful !!!');
            if ($data->otp == 1) {
              redirect('home/retailer_reset_pwd');
            } else {
            redirect('home');
            $this->session->set_flashdata('login_msg', '');                
            }            
        } else {

            $this->session->set_flashdata('login_msg', 'Wrong Username or Password');
            $this->output_to_view('home/retailer_login',$data);
            $this->session->set_flashdata('login_msg', '');
        }
      } else {
        $data = "";
        $this->session->set_flashdata('login_msg', 'Please Login!!!');

        $this->output_to_view('home/retailer_login',$data);
      }
      
        
    }

    public function retailer_logout (){
      if (isset($_SESSION["user_name"]) && !empty($_SESSION["user_name"]) && isset($_SESSION["logged_in"]) && $_SESSION["logged_in"] == 1) {
        unset($_SESSION["logged_in"]);
        unset($_SESSION["user_name"]);
        unset($_SESSION["user_role"]);
        unset($_SESSION["user_id"]);
        unset($_SESSION["user_status"]);
        $this->session->set_flashdata('login_msg', 'Logged Out Successfully!!!');
      }
      $this->session->userdata["logged_in"] = 0;
      // print_r($_SESSION);exit();
      redirect('home');
    }
      


    function get_prod_info()
      { 
        $id = $_POST["id"];
        $this->load->model("home_model");
        $output["p_info"] = $this->home_model->get_product_info($id);
        // $p_info = "";
        $output["p_images"] = $this->home_model->get_product_images($id);
        // $output = array_merge((array) $p_info, $p_imgs);
        echo json_encode($output);
      }

    function output_to_view($view = null,$data = null)
      {
        $this->load->view($view,$data); 
      }

    /*public function verify_login() {
        $data = $this->admin_model->check_user();
        if ($data):
            redirect('admin/dashboard');
        else:

            $this->session->set_flashdata('login', 'Wrong Username or Password');
            $this->load->view('admin/login');
        endif;
    }

    public function logout() {
        if ($this->session->userdata('user_name')):
            $this->session->sess_destroy();
            $this->load->view('admin/login');
        else:
            $this->load->view('admin/login');
        endif;
    }

    public function dashboard() {
        $output['content'] = 'dashboard';
        $output['title'] = 'Dashboard';
        $output['header'] = 'Dashboard';
        $output['seller_count'] = $this->admin_model->get_seller_count();
        $this->load->view('admin_template', $output);
    }

    public function seller_register() {
        $data['content'] = 'seller_register';
        $data['title'] = 'seller_register';
        $this->load->view('template/admin_template', $data);
    }

    public function add_seller() {
        $this->admin_model->add_seller();
        redirect('admin/seller_register');
    }

    public function view_seller() {
        $data['content'] = 'view_seller';
        $data['title'] = 'view_seller';
        $data['get_seller'] = $this->admin_model->get_seller();

        $this->load->view('template/admin_template', $data);
    }

    public function delete_seller() {
        $id = $_REQUEST['id'];
        $this->admin_model->delete_seller($id);
        redirect('admin/seller_register');
    }

    public function edit_seller() {
        $id = $_REQUEST['id'];
        $data['seller'] = $this->admin_model->get_seller_id($id);
        $data['content'] = 'edit_seller';
        $data['title'] = 'edit_seller';
//        $data['get_seller'] = $this->admin_model->get_seller();

        $this->load->view('template/admin_template', $data);
    }

    public function update_seller() {

        $this->admin_model->update_seller($id);
        redirect('admin/view_seller');
    }*/

}
